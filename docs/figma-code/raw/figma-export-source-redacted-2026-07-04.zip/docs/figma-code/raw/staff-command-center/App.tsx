import { useState, useMemo } from "react";
import {
  LayoutDashboard, Megaphone, Calendar, Rss, Film,
  Database, BarChart3, Settings, Search, ChevronDown,
  X, AlertTriangle, CheckCircle, Clock, ArrowRight,
  Users, TrendingUp, Eye, Heart, MessageSquare, Share2,
  Star, Bell, RefreshCw, ExternalLink, Plus,
  Send, Tag, Globe, Activity, Zap,
  Shield, Terminal, AlertCircle, FileText,
  Video, MoreHorizontal, ChevronRight,
  Target, Award, Lightbulb, Filter, Download,
  Play, BookOpen, CheckSquare, Bookmark, Flag,
  BarChart2, PieChart, Layers, Radio, Inbox,
  UserCheck, TrendingDown, Circle, Wifi, WifiOff,
  RotateCcw, Info, MapPin, Hash, Camera, Mail,
  ChevronUp, Package, Link, Edit3, Copy, Trash2,
  GitBranch
} from "lucide-react";
import {
  LibraryScreen as SOPLibraryScreen,
  BuilderScreen as SOPBuilderScreen,
} from "../imports/pasted_text/campaign-data.tsx";
import type { SOPCampaign } from "../imports/pasted_text/campaign-data.tsx";
import { AdminPanel } from "../imports/pasted_text/mock-data.tsx";

/* ─────────────────────────────────────────────────────────── */
/*  TYPES                                                       */
/* ─────────────────────────────────────────────────────────── */

type RiskLevel = "healthy" | "at-risk" | "intervene";
type Decision = "Advance" | "Hold" | "Intervene" | "—";
type CampaignStatus = "on-track" | "behind" | "not-started" | "complete" | "paused";

interface Chapter {
  id: string;
  name: string;
  school: string;
  country: string;
  region: string;
  coach: string;
  leaders: string[];
  activeMembers: number;
  campaign: string;
  campaignStatus: CampaignStatus;
  leads: number;
  rsvps: number;
  attendance: number;
  followUps: number;
  assignments: number;
  evidencePending: number;
  evidenceApproved: number;
  pointsWeek: number;
  hubspotLifecycle: string;
  hubspotTasks: number;
  lumaEvents: number;
  lastActivity: string;
  risk: RiskLevel;
  decision: Decision;
  healthScore: number;
  newMembers: number;
  feedViews: number;
  chapterType: "established" | "new" | "growing";
  medlifeRegion: "New England" | "Mid Atlantic" | "South" | "Midwest" | "West" | "Puerto Rico" | "UK" | "Canada" | "International";
  // Event & NPS cornerstones
  eventsThisYear: number;
  eventsThisMonth: number;
  leadAttendancePct: number;   // % of leads who attended ≥1 event
  avgNpsScore: number | null;  // NPS -100 to 100; null = no surveys yet
  totalPointsYear: number;
}

type Platform = "linkedin" | "instagram" | "facebook" | "loom" | "youtube" | "tiktok" | "upload";

interface ContentCard {
  id: string;
  type: "proof-video" | "bridge-video" | "best-practice" | "event-recap" | "student-story" | "campaign-tip" | "announcement" | "social-link";
  platform?: Platform;
  url?: string;
  linkTitle?: string;
  linkDomain?: string;
  previewImage: string;
  chapter: string;
  student: string;
  campaign: string;
  assignment: string;
  submitted: string;
  consent: "public" | "chapter-only" | "multi-chapter" | "pending" | "none";
  visibility: "pending" | "chapter" | "selected" | "all" | "rejected";
  qualityScore: number;
  engagementPotential: "high" | "medium" | "low";
  views?: number;
  likes?: number;
  duration?: string;
  caption?: string;
}

interface BestPractice {
  id: string;
  title: string;
  chapter: string;
  campaign: string;
  why: string;
  kpiResult: string;
  type: string;
  country: string;
  engagementScore: number;
  recommended: string[];
}


type Screen = "chapters" | "campaigns" | "events" | "ugc" | "reports" | "admin" | "best-practices" | "sops";

/* ─────────────────────────────────────────────────────────── */
/*  MOCK DATA                                                   */
/* ─────────────────────────────────────────────────────────── */

const CHAPTERS: Chapter[] = [
  { id:"ch1",  name:"UC Berkeley",          school:"University of California, Berkeley",       country:"USA",       region:"North America",   coach:"Maria Santos",  leaders:["Priya Nair","Ethan Liu"],           activeMembers:48, campaign:"Rush Month",          campaignStatus:"on-track",   leads:87,  rsvps:62, attendance:51, followUps:54, assignments:38, evidencePending:4,  evidenceApproved:22, pointsWeek:1240, hubspotLifecycle:"MQL", hubspotTasks:3,  lumaEvents:4, lastActivity:"2h ago",  risk:"healthy",   decision:"Advance",   healthScore:91, newMembers:12, feedViews:340, chapterType:"established", eventsThisYear:18, eventsThisMonth:4, leadAttendancePct:59, avgNpsScore:67,   totalPointsYear:14200, medlifeRegion:"West"           },
  { id:"ch2",  name:"Yale University",       school:"Yale University",                         country:"USA",       region:"North America",   coach:"James Okafor",  leaders:["Sofia Chen"],                      activeMembers:22, campaign:"Rush Month",          campaignStatus:"behind",     leads:19,  rsvps:11, attendance:7,  followUps:4,  assignments:12, evidencePending:8,  evidenceApproved:3,  pointsWeek:210,  hubspotLifecycle:"Lead", hubspotTasks:11, lumaEvents:1, lastActivity:"3d ago",  risk:"at-risk",   decision:"Hold",      healthScore:38, newMembers:1,  feedViews:45,  chapterType:"growing",     eventsThisYear:6,  eventsThisMonth:1, leadAttendancePct:37, avgNpsScore:28,   totalPointsYear:3100,  medlifeRegion:"New England"    },
  { id:"ch3",  name:"University of Florida", school:"University of Florida",                   country:"USA",       region:"North America",   coach:"Maria Santos",  leaders:["Marcus Webb","Diana Torres"],       activeMembers:61, campaign:"Rush Month",          campaignStatus:"on-track",   leads:104, rsvps:91, attendance:78, followUps:88, assignments:55, evidencePending:2,  evidenceApproved:41, pointsWeek:1680, hubspotLifecycle:"SQL", hubspotTasks:1,  lumaEvents:5, lastActivity:"4h ago",  risk:"healthy",   decision:"Advance",   healthScore:96, newMembers:18, feedViews:510, chapterType:"established", eventsThisYear:22, eventsThisMonth:5, leadAttendancePct:75, avgNpsScore:71,   totalPointsYear:19800, medlifeRegion:"South"          },
  { id:"ch4",  name:"McGill University",     school:"McGill University",                       country:"Canada",    region:"North America",   coach:"Aisha Kamara",  leaders:["Louis Tremblay"],                  activeMembers:34, campaign:"SLT Promotion",       campaignStatus:"on-track",   leads:47,  rsvps:38, attendance:31, followUps:35, assignments:28, evidencePending:1,  evidenceApproved:17, pointsWeek:820,  hubspotLifecycle:"MQL", hubspotTasks:2,  lumaEvents:3, lastActivity:"6h ago",  risk:"healthy",   decision:"Advance",   healthScore:82, newMembers:7,  feedViews:210, chapterType:"established", eventsThisYear:15, eventsThisMonth:3, leadAttendancePct:66, avgNpsScore:58,   totalPointsYear:10400, medlifeRegion:"Canada"         },
  { id:"ch5",  name:"PUCP Lima",             school:"Pontificia Universidad Católica del Perú",country:"Peru",      region:"Latin America",   coach:"Carlos Quispe", leaders:["Valentina Ruiz","Alejandro Flores"],activeMembers:41, campaign:"Rush Month",          campaignStatus:"behind",     leads:38,  rsvps:22, attendance:14, followUps:11, assignments:20, evidencePending:6,  evidenceApproved:8,  pointsWeek:380,  hubspotLifecycle:"Lead", hubspotTasks:7,  lumaEvents:2, lastActivity:"1d ago",  risk:"at-risk",   decision:"Hold",      healthScore:44, newMembers:3,  feedViews:120, chapterType:"growing",     eventsThisYear:9,  eventsThisMonth:2, leadAttendancePct:37, avgNpsScore:44,   totalPointsYear:5800,  medlifeRegion:"International"  },
  { id:"ch6",  name:"UNMSM Lima",            school:"Universidad Nacional Mayor de San Marcos", country:"Peru",      region:"Latin America",   coach:"Carlos Quispe", leaders:["Ricardo Mamani"],                  activeMembers:17, campaign:"Rush Month",          campaignStatus:"not-started",leads:6,   rsvps:2,  attendance:2,  followUps:0,  assignments:4,  evidencePending:12, evidenceApproved:0,  pointsWeek:40,   hubspotLifecycle:"Lead", hubspotTasks:14, lumaEvents:0, lastActivity:"6d ago",  risk:"intervene", decision:"Intervene", healthScore:12, newMembers:0,  feedViews:18,  chapterType:"new",         eventsThisYear:2,  eventsThisMonth:0, leadAttendancePct:33, avgNpsScore:null, totalPointsYear:900,   medlifeRegion:"International"  },
  { id:"ch7",  name:"USP São Paulo",         school:"Universidade de São Paulo",               country:"Brazil",    region:"Latin America",   coach:"Fernanda Lima", leaders:["Beatriz Souza","Gabriel Martins"], activeMembers:55, campaign:"Moving Mountains",    campaignStatus:"on-track",   leads:78,  rsvps:69, attendance:58, followUps:61, assignments:44, evidencePending:3,  evidenceApproved:33, pointsWeek:1420, hubspotLifecycle:"MQL", hubspotTasks:2,  lumaEvents:4, lastActivity:"1h ago",  risk:"healthy",   decision:"Advance",   healthScore:88, newMembers:14, feedViews:440, chapterType:"established", eventsThisYear:19, eventsThisMonth:4, leadAttendancePct:74, avgNpsScore:65,   totalPointsYear:17400, medlifeRegion:"International"  },
  { id:"ch8",  name:"UFMG Belo Horizonte",   school:"Universidade Federal de Minas Gerais",    country:"Brazil",    region:"Latin America",   coach:"Fernanda Lima", leaders:["Lucas Pereira"],                   activeMembers:28, campaign:"Rush Month",          campaignStatus:"behind",     leads:22,  rsvps:14, attendance:9,  followUps:7,  assignments:15, evidencePending:9,  evidenceApproved:4,  pointsWeek:190,  hubspotLifecycle:"Lead", hubspotTasks:8,  lumaEvents:1, lastActivity:"2d ago",  risk:"at-risk",   decision:"Hold",      healthScore:33, newMembers:2,  feedViews:65,  chapterType:"growing",     eventsThisYear:7,  eventsThisMonth:1, leadAttendancePct:41, avgNpsScore:38,   totalPointsYear:4200,  medlifeRegion:"International"  },
  { id:"ch9",  name:"UNAH Tegucigalpa",      school:"Universidad Nacional Autónoma de Honduras",country:"Honduras",  region:"Central America",  coach:"Lucia Herrera", leaders:["Andrea Sánchez","Miguel Reyes"],   activeMembers:39, campaign:"Chapter Engagement",  campaignStatus:"on-track",   leads:52,  rsvps:44, attendance:37, followUps:40, assignments:30, evidencePending:2,  evidenceApproved:19, pointsWeek:910,  hubspotLifecycle:"MQL", hubspotTasks:3,  lumaEvents:3, lastActivity:"3h ago",  risk:"healthy",   decision:"Advance",   healthScore:79, newMembers:8,  feedViews:280, chapterType:"established", eventsThisYear:14, eventsThisMonth:3, leadAttendancePct:71, avgNpsScore:62,   totalPointsYear:11900, medlifeRegion:"International"  },
  { id:"ch10", name:"UNAN Managua",          school:"Universidad Nacional Autónoma de Nicaragua",country:"Nicaragua",region:"Central America",  coach:"Lucia Herrera", leaders:["Karla López"],                     activeMembers:21, campaign:"Rush Month",          campaignStatus:"behind",     leads:14,  rsvps:7,  attendance:5,  followUps:3,  assignments:9,  evidencePending:7,  evidenceApproved:2,  pointsWeek:130,  hubspotLifecycle:"Lead", hubspotTasks:9,  lumaEvents:1, lastActivity:"3d ago",  risk:"at-risk",   decision:"Hold",      healthScore:29, newMembers:1,  feedViews:38,  chapterType:"growing",     eventsThisYear:5,  eventsThisMonth:1, leadAttendancePct:36, avgNpsScore:35,   totalPointsYear:3600,  medlifeRegion:"International"  },
  { id:"ch11", name:"University of Nairobi", school:"University of Nairobi",                   country:"Kenya",     region:"Africa",           coach:"Samuel Mutua",  leaders:["Faith Wanjiru","Daniel Otieno"],    activeMembers:44, campaign:"Grow the Movement",   campaignStatus:"on-track",   leads:61,  rsvps:54, attendance:46, followUps:50, assignments:37, evidencePending:1,  evidenceApproved:26, pointsWeek:1090, hubspotLifecycle:"MQL", hubspotTasks:2,  lumaEvents:4, lastActivity:"5h ago",  risk:"healthy",   decision:"Advance",   healthScore:85, newMembers:11, feedViews:320, chapterType:"established", eventsThisYear:16, eventsThisMonth:3, leadAttendancePct:75, avgNpsScore:69,   totalPointsYear:14800, medlifeRegion:"International"  },
  { id:"ch12", name:"Makerere University",   school:"Makerere University",                     country:"Uganda",    region:"Africa",           coach:"Samuel Mutua",  leaders:["Grace Nakato"],                    activeMembers:31, campaign:"Rush Month",          campaignStatus:"on-track",   leads:43,  rsvps:36, attendance:29, followUps:32, assignments:24, evidencePending:3,  evidenceApproved:14, pointsWeek:690,  hubspotLifecycle:"MQL", hubspotTasks:4,  lumaEvents:3, lastActivity:"8h ago",  risk:"healthy",   decision:"Advance",   healthScore:74, newMembers:6,  feedViews:190, chapterType:"established", eventsThisYear:12, eventsThisMonth:3, leadAttendancePct:67, avgNpsScore:61,   totalPointsYear:9400,  medlifeRegion:"International"  },
  { id:"ch13", name:"Stanford University",   school:"Stanford University",                     country:"USA",       region:"North America",   coach:"James Okafor",  leaders:["Mia Rodriguez","Chris Park"],       activeMembers:52, campaign:"Leadership Transition",campaignStatus:"complete",   leads:91,  rsvps:80, attendance:68, followUps:75, assignments:60, evidencePending:0,  evidenceApproved:48, pointsWeek:1890, hubspotLifecycle:"SQL", hubspotTasks:0,  lumaEvents:5, lastActivity:"30m ago", risk:"healthy",   decision:"Advance",   healthScore:98, newMembers:20, feedViews:620, chapterType:"established", eventsThisYear:24, eventsThisMonth:5, leadAttendancePct:75, avgNpsScore:78,   totalPointsYear:22100, medlifeRegion:"West"           },
  { id:"ch14", name:"Johns Hopkins",         school:"Johns Hopkins University",                country:"USA",       region:"North America",   coach:"James Okafor",  leaders:["Alex Kim"],                        activeMembers:26, campaign:"SLT Promotion",       campaignStatus:"behind",     leads:21,  rsvps:12, attendance:8,  followUps:6,  assignments:11, evidencePending:10, evidenceApproved:2,  pointsWeek:180,  hubspotLifecycle:"Lead", hubspotTasks:12, lumaEvents:1, lastActivity:"4d ago",  risk:"at-risk",   decision:"Hold",      healthScore:27, newMembers:1,  feedViews:42,  chapterType:"growing",     eventsThisYear:7,  eventsThisMonth:1, leadAttendancePct:38, avgNpsScore:31,   totalPointsYear:3800,  medlifeRegion:"Mid Atlantic"   },
  { id:"ch15", name:"UPCH Lima",             school:"Universidad Peruana Cayetano Heredia",    country:"Peru",      region:"Latin America",   coach:"Carlos Quispe", leaders:["Isabella Morales","Juan Chávez"],   activeMembers:49, campaign:"Rush Month",          campaignStatus:"on-track",   leads:72,  rsvps:61, attendance:52, followUps:57, assignments:42, evidencePending:3,  evidenceApproved:29, pointsWeek:1190, hubspotLifecycle:"MQL", hubspotTasks:2,  lumaEvents:4, lastActivity:"2h ago",  risk:"healthy",   decision:"Advance",   healthScore:87, newMembers:13, feedViews:380, chapterType:"established", eventsThisYear:17, eventsThisMonth:4, leadAttendancePct:72, avgNpsScore:64,   totalPointsYear:15600, medlifeRegion:"International"  },
  { id:"ch16", name:"Universidad de Chile",  school:"Universidad de Chile",                    country:"Chile",     region:"Latin America",   coach:"Fernanda Lima", leaders:["Camila Vásquez"],                  activeMembers:19, campaign:"Rush Month",          campaignStatus:"paused",     leads:11,  rsvps:4,  attendance:3,  followUps:2,  assignments:5,  evidencePending:11, evidenceApproved:1,  pointsWeek:60,   hubspotLifecycle:"Lead", hubspotTasks:13, lumaEvents:0, lastActivity:"5d ago",  risk:"at-risk",   decision:"Intervene", healthScore:19, newMembers:0,  feedViews:22,  chapterType:"new",         eventsThisYear:4,  eventsThisMonth:0, leadAttendancePct:27, avgNpsScore:25,   totalPointsYear:2100,  medlifeRegion:"International"  },
  { id:"ch17", name:"UNAM Mexico City",      school:"Universidad Nacional Autónoma de México",country:"Mexico",    region:"Latin America",   coach:"Carlos Quispe", leaders:["Rodrigo Hernández","Daniela Vargas"],activeMembers:63, campaign:"Moving Mountains",    campaignStatus:"on-track",   leads:99,  rsvps:86, attendance:74, followUps:82, assignments:58, evidencePending:2,  evidenceApproved:44, pointsWeek:1760, hubspotLifecycle:"SQL", hubspotTasks:1,  lumaEvents:5, lastActivity:"1h ago",  risk:"healthy",   decision:"Advance",   healthScore:94, newMembers:19, feedViews:570, chapterType:"established", eventsThisYear:21, eventsThisMonth:5, leadAttendancePct:75, avgNpsScore:70,   totalPointsYear:20400, medlifeRegion:"International"  },
  { id:"ch18", name:"University of Ghana",   school:"University of Ghana, Legon",             country:"Ghana",     region:"Africa",           coach:"Samuel Mutua",  leaders:["Kwame Asante"],                    activeMembers:14, campaign:"Start a Chapter",     campaignStatus:"not-started",leads:4,   rsvps:1,  attendance:1,  followUps:0,  assignments:2,  evidencePending:8,  evidenceApproved:0,  pointsWeek:20,   hubspotLifecycle:"Lead", hubspotTasks:16, lumaEvents:0, lastActivity:"8d ago",  risk:"intervene", decision:"Intervene", healthScore:8,  newMembers:0,  feedViews:9,   chapterType:"new",         eventsThisYear:1,  eventsThisMonth:0, leadAttendancePct:25, avgNpsScore:null, totalPointsYear:600,   medlifeRegion:"International"  },
  { id:"ch19", name:"University of Toronto", school:"University of Toronto",                  country:"Canada",    region:"North America",   coach:"Aisha Kamara",  leaders:["Nadia Singh","Tommy Chen"],         activeMembers:45, campaign:"Chapter Engagement",  campaignStatus:"on-track",   leads:63,  rsvps:55, attendance:47, followUps:51, assignments:38, evidencePending:2,  evidenceApproved:23, pointsWeek:1050, hubspotLifecycle:"MQL", hubspotTasks:3,  lumaEvents:4, lastActivity:"3h ago",  risk:"healthy",   decision:"Advance",   healthScore:83, newMembers:10, feedViews:310, chapterType:"established", eventsThisYear:16, eventsThisMonth:3, leadAttendancePct:75, avgNpsScore:63,   totalPointsYear:13800, medlifeRegion:"Canada"         },
  { id:"ch20", name:"MIT",                   school:"Massachusetts Institute of Technology",  country:"USA",       region:"North America",   coach:"Maria Santos",  leaders:["Elise Park","Jordan Nakamura"],     activeMembers:57, campaign:"Leadership Transition",campaignStatus:"on-track",   leads:82,  rsvps:74, attendance:63, followUps:70, assignments:51, evidencePending:1,  evidenceApproved:38, pointsWeek:1540, hubspotLifecycle:"SQL", hubspotTasks:1,  lumaEvents:5, lastActivity:"45m ago", risk:"healthy",   decision:"Advance",   healthScore:93, newMembers:16, feedViews:490, chapterType:"established", eventsThisYear:20, eventsThisMonth:5, leadAttendancePct:77, avgNpsScore:74,   totalPointsYear:18200, medlifeRegion:"New England"    },
];

const UGC_CARDS: ContentCard[] = [
  {
    id:"ugc1", type:"social-link", platform:"instagram",
    url:"https://instagram.com/p/abc123",
    linkTitle:"Rush Month tabling — 80+ students stopped by our table today 🩺",
    linkDomain:"instagram.com",
    previewImage:"https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600&h=340&fit=crop&auto=format",
    chapter:"UC Berkeley", student:"Priya Nair", campaign:"Rush Month", assignment:"Tabling Event Recap",
    submitted:"2h ago", consent:"public", visibility:"pending", qualityScore:94, engagementPotential:"high",
    views:0, likes:0, caption:"Incredible energy at our Rush Month tabling event! Over 80 people stopped by."
  },
  {
    id:"ugc2", type:"social-link", platform:"loom",
    url:"https://loom.com/share/xyz789",
    linkTitle:"Bridge Video: Why I joined MEDLIFE — Rodrigo Hernández, UNAM",
    linkDomain:"loom.com",
    previewImage:"https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&h=340&fit=crop&auto=format",
    chapter:"UNAM Mexico City", student:"Rodrigo Hernández", campaign:"Moving Mountains", assignment:"Bridge Video - My Why",
    submitted:"5h ago", consent:"multi-chapter", visibility:"pending", qualityScore:88, engagementPotential:"high",
    duration:"3:42", caption:"A powerful story about why healthcare access matters in rural communities."
  },
  {
    id:"ugc3", type:"social-link", platform:"facebook",
    url:"https://facebook.com/posts/def456",
    linkTitle:"UF MEDLIFE Info Night Recap — 78 attendees, best turnout ever!",
    linkDomain:"facebook.com",
    previewImage:"https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&h=340&fit=crop&auto=format",
    chapter:"University of Florida", student:"Marcus Webb", campaign:"Rush Month", assignment:"Info Night Recap",
    submitted:"1d ago", consent:"public", visibility:"chapter", qualityScore:76, engagementPotential:"medium",
    views:142, likes:31, caption:"Our info night brought in 78 attendees — best turnout ever!"
  },
  {
    id:"ugc4", type:"best-practice", platform:"upload",
    linkTitle:"Best Practice: QR Lead Capture — 91 leads in one weekend",
    linkDomain:"mymedlife.org",
    previewImage:"https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=600&h=340&fit=crop&auto=format",
    chapter:"Stanford University", student:"Mia Rodriguez", campaign:"Leadership Transition", assignment:"Best Practice: QR Lead Capture",
    submitted:"1d ago", consent:"public", visibility:"selected", qualityScore:97, engagementPotential:"high",
    views:380, likes:87, caption:"How we captured 91 leads in one weekend using QR codes at 5 campus events."
  },
  {
    id:"ugc5", type:"social-link", platform:"youtube",
    url:"https://youtube.com/watch?v=ghi012",
    linkTitle:"Faith Wanjiru: How MEDLIFE changed my understanding of community health",
    linkDomain:"youtube.com",
    previewImage:"https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=600&h=340&fit=crop&auto=format",
    chapter:"University of Nairobi", student:"Faith Wanjiru", campaign:"Grow the Movement", assignment:"Student Story",
    submitted:"2d ago", consent:"public", visibility:"pending", qualityScore:91, engagementPotential:"high",
    duration:"4:10", caption:"Faith shares how MEDLIFE changed her understanding of community health."
  },
  {
    id:"ugc6", type:"social-link", platform:"linkedin",
    url:"https://linkedin.com/posts/jkl345",
    linkTitle:"PUCP Lima Rush Month — tabling at the Faculty of Medicine",
    linkDomain:"linkedin.com",
    previewImage:"https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600&h=340&fit=crop&auto=format",
    chapter:"PUCP Lima", student:"Valentina Ruiz", campaign:"Rush Month", assignment:"Tabling Event",
    submitted:"3d ago", consent:"chapter-only", visibility:"pending", qualityScore:62, engagementPotential:"medium",
    duration:"1:34", caption:"Rush table at the faculty of medicine."
  },
  {
    id:"ugc7", type:"event-recap", platform:"upload",
    linkTitle:"Makerere MEDLIFE — Info Session Highlights",
    linkDomain:"mymedlife.org",
    previewImage:"https://images.unsplash.com/photo-1531983412531-1f49a365ffed?w=600&h=340&fit=crop&auto=format",
    chapter:"Makerere University", student:"Grace Nakato", campaign:"Rush Month", assignment:"Info Session",
    submitted:"3d ago", consent:"pending", visibility:"pending", qualityScore:79, engagementPotential:"medium",
    views:0, likes:0, caption:"Consent form still pending."
  },
  {
    id:"ugc8", type:"social-link", platform:"tiktok",
    url:"https://tiktok.com/@ufmgmedlife/video/mno678",
    linkTitle:"Quick tabling clip — UFMG Belo Horizonte Rush Month",
    linkDomain:"tiktok.com",
    previewImage:"https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?w=600&h=340&fit=crop&auto=format",
    chapter:"UFMG Belo Horizonte", student:"Lucas Pereira", campaign:"Rush Month", assignment:"Tabling",
    submitted:"4d ago", consent:"none", visibility:"rejected", qualityScore:55, engagementPotential:"low",
    duration:"0:48", caption:"Short clip, no consent obtained."
  },
];

const BEST_PRACTICES: BestPractice[] = [
  { id:"bp1", title:"QR Code Lead Capture at Multi-Event Weekend", chapter:"Stanford University", campaign:"Rush Month", why:"Chapter deployed QR codes at 5 events simultaneously with real-time HubSpot sync, capturing 91 qualified leads in 48 hours.", kpiResult:"+91 leads, 74% RSVP rate", type:"Event Strategy", country:"USA", engagementScore:97, recommended:["Yale University","Johns Hopkins","PUCP Lima"] },
  { id:"bp2", title:"Morning Motivation Text Sequence for Members", chapter:"UC Berkeley", campaign:"Chapter Engagement", why:"Coach co-created a 5-day WhatsApp check-in series that boosted assignment completion from 62% to 89% in 2 weeks.", kpiResult:"+27% assignment completion", type:"Coach Communication", country:"USA", engagementScore:92, recommended:["UFMG Belo Horizonte","UNAN Managua","University of Ghana"] },
  { id:"bp3", title:"'Why I Travel' Bridge Video Campaign", chapter:"UNAM Mexico City", campaign:"Moving Mountains", why:"Leaders filmed 3-minute personal story videos and shared them on chapter social media before Rush, driving 40% more RSVPs than previous year.", kpiResult:"+40% RSVPs vs. baseline", type:"Content Strategy", country:"Mexico", engagementScore:88, recommended:["UNMSM Lima","Universidad de Chile","UNAH Tegucigalda"] },
  { id:"bp4", title:"Faculty Partnership for Tabling Prime Spots", chapter:"University of Florida", campaign:"Rush Month", why:"Chapter partnered with Health Sciences dean office to secure 3 high-traffic tabling locations, resulting in 104 leads captured.", kpiResult:"104 leads, best in region", type:"Outreach Strategy", country:"USA", engagementScore:85, recommended:["McGill University","University of Toronto"] },
  { id:"bp5", title:"Peer-to-Peer Recruitment Bonus Structure", chapter:"USP São Paulo", campaign:"Grow the Movement", why:"Members earned bonus points for recruiting classmates who attended events, creating a viral spread effect.", kpiResult:"+14 new members in one campaign", type:"Membership Growth", country:"Brazil", engagementScore:81, recommended:["UFMG Belo Horizonte","UNMSM Lima","University of Ghana"] },
];


/* ─────────────────────────────────────────────────────────── */
/*  UTILITY COMPONENTS                                          */
/* ─────────────────────────────────────────────────────────── */

function RiskPill({ level }: { level: RiskLevel }) {
  const map = {
    healthy: "bg-emerald-50 text-emerald-700 border border-emerald-200",
    "at-risk": "bg-amber-50 text-amber-700 border border-amber-200",
    intervene: "bg-red-50 text-red-700 border border-red-200",
  };
  const label = { healthy: "Healthy", "at-risk": "At Risk", intervene: "Intervene" };
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-mono font-medium ${map[level]}`}>
      <Circle className="w-1.5 h-1.5 fill-current" />
      {label[level]}
    </span>
  );
}

function CampaignBadge({ status }: { status: CampaignStatus }) {
  const map: Record<CampaignStatus, string> = {
    "on-track": "bg-sky-50 text-sky-700 border border-sky-200",
    "behind": "bg-orange-50 text-orange-700 border border-orange-200",
    "not-started": "bg-gray-100 text-gray-500 border border-gray-200",
    "complete": "bg-emerald-50 text-emerald-700 border border-emerald-200",
    "paused": "bg-purple-50 text-purple-600 border border-purple-200",
  };
  const label: Record<CampaignStatus, string> = {
    "on-track": "On Track", "behind": "Behind", "not-started": "Not Started",
    "complete": "Complete", "paused": "Paused"
  };
  return (
    <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${map[status]}`}>
      {label[status]}
    </span>
  );
}

function DecisionControl({ value, onChange }: { value: Decision; onChange: (v: Decision) => void }) {
  const options: Decision[] = ["Advance", "Hold", "Intervene"];
  const map = {
    Advance: "bg-emerald-100 text-emerald-800 ring-1 ring-emerald-300",
    Hold: "bg-amber-100 text-amber-800 ring-1 ring-amber-300",
    Intervene: "bg-red-100 text-red-800 ring-1 ring-red-300",
    "—": "bg-gray-100 text-gray-500",
  };
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value as Decision)}
      className={`text-xs font-semibold px-2 py-1 rounded border-0 cursor-pointer outline-none ${map[value]} appearance-none`}
    >
      {options.map((o) => <option key={o} value={o}>{o}</option>)}
    </select>
  );
}

function KPICard({ label, value, sub, color = "blue" }: { label: string; value: string | number; sub?: string; color?: "blue" | "yellow" | "green" | "red" | "gray" }) {
  const accent = {
    blue: "border-t-2 border-t-blue-600",
    yellow: "border-t-2 border-t-amber-400",
    green: "border-t-2 border-t-emerald-500",
    red: "border-t-2 border-t-red-500",
    gray: "border-t-2 border-t-gray-300",
  };
  return (
    <div className={`bg-white rounded-lg p-4 ${accent[color]} shadow-sm`}>
      <div className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-1">{label}</div>
      <div className="text-2xl font-bold font-mono text-foreground">{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
    </div>
  );
}

function ConsentTag({ status }: { status: ContentCard["consent"] }) {
  const map = {
    public: "bg-emerald-100 text-emerald-800",
    "chapter-only": "bg-sky-100 text-sky-800",
    "multi-chapter": "bg-violet-100 text-violet-800",
    pending: "bg-amber-100 text-amber-800",
    none: "bg-red-100 text-red-800",
  };
  const label = {
    public: "Public", "chapter-only": "Chapter Only",
    "multi-chapter": "Multi-Chapter", pending: "Consent Pending", none: "No Consent"
  };
  return <span className={`px-2 py-0.5 rounded text-xs font-semibold ${map[status]}`}>{label[status]}</span>;
}

function IntegrationStatus({ name, status, lastSync }: { name: string; status: "live" | "mock" | "error" | "degraded"; lastSync: string }) {
  const map = { live: "text-emerald-600", mock: "text-amber-500", error: "text-red-600", degraded: "text-orange-500" };
  const icon = { live: <Wifi className="w-3 h-3" />, mock: <Radio className="w-3 h-3" />, error: <WifiOff className="w-3 h-3" />, degraded: <AlertCircle className="w-3 h-3" /> };
  const label = { live: "Live", mock: "Mock", error: "Error", degraded: "Degraded" };
  return (
    <div className="flex items-center justify-between py-2.5 border-b border-border last:border-0">
      <div className="flex items-center gap-2">
        <div className={`p-1.5 rounded bg-muted ${map[status]}`}>{icon[status]}</div>
        <div>
          <div className="text-sm font-semibold text-foreground">{name}</div>
          <div className="text-xs text-muted-foreground">Last sync: {lastSync}</div>
        </div>
      </div>
      <span className={`text-xs font-mono font-bold ${map[status]}`}>{label[status]}</span>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────── */
/*  NPS UTILITIES                                               */
/* ─────────────────────────────────────────────────────────── */

function NpsScore({ score }: { score: number | null }) {
  if (score === null) return <span className="text-xs text-muted-foreground font-mono italic">No data</span>;
  const cls = score >= 60 ? "text-emerald-600 bg-emerald-50 border-emerald-200"
    : score >= 30 ? "text-sky-600 bg-sky-50 border-sky-200"
    : score >= 0  ? "text-amber-600 bg-amber-50 border-amber-200"
    : "text-red-600 bg-red-50 border-red-200";
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-mono font-bold border ${cls}`}>
      {score > 0 ? "+" : ""}{score}
    </span>
  );
}

function NPSSurveyPreview({ onClose }: { onClose: () => void }) {
  const [selected, setSelected] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 backdrop-blur-sm" onClick={onClose}>
      <div className="relative" onClick={e => e.stopPropagation()}>
        <div className="w-[300px] bg-white rounded-3xl shadow-2xl border-[3px] border-slate-200 overflow-hidden">
          <div className="bg-primary px-4 py-3 flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-accent flex items-center justify-center text-[9px] font-black text-sidebar">M</div>
            <span className="text-white text-xs font-bold">myMEDLIFE</span>
          </div>
          {!submitted ? (
            <div className="p-5 space-y-4">
              <div>
                <div className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider mb-2 text-center">Quick Event Feedback</div>
                <p className="text-sm font-semibold text-foreground text-center leading-snug">
                  How likely are you to recommend MEDLIFE to a friend?
                </p>
              </div>
              <div>
                <div className="grid grid-cols-11 gap-0.5 mb-1.5">
                  {Array.from({ length: 11 }, (_, i) => (
                    <button
                      key={i}
                      onClick={() => setSelected(i)}
                      className={`py-1.5 rounded text-xs font-bold transition-all ${
                        selected === i
                          ? i >= 9 ? "bg-emerald-500 text-white" : i >= 7 ? "bg-sky-500 text-white" : "bg-red-400 text-white"
                          : "bg-muted text-muted-foreground hover:bg-muted/70"
                      }`}
                    >
                      {i}
                    </button>
                  ))}
                </div>
                <div className="flex justify-between text-[9px] text-muted-foreground">
                  <span>Not likely</span><span>Very likely</span>
                </div>
              </div>
              <textarea
                placeholder="What stood out? (optional)"
                rows={2}
                className="w-full bg-muted/60 rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground/60 resize-none focus:outline-none border border-border"
              />
              <button
                onClick={() => setSubmitted(true)}
                disabled={selected === null}
                className="w-full py-2.5 bg-primary text-white rounded-xl text-sm font-semibold disabled:opacity-30 hover:bg-primary/90 transition-colors"
              >
                Submit
              </button>
              <p className="text-[10px] text-muted-foreground text-center">Takes &lt;30 sec · Sent automatically after every event</p>
            </div>
          ) : (
            <div className="p-8 text-center space-y-3">
              <div className="text-3xl">🎉</div>
              <div className="font-bold text-foreground text-sm">Thank you!</div>
              <div className="text-xs text-muted-foreground leading-relaxed">Your feedback helps MEDLIFE improve every event.</div>
            </div>
          )}
        </div>
        <div className="text-center mt-3">
          <span className="text-xs text-white/80 bg-black/30 px-3 py-1 rounded-full">Students receive this after every event</span>
        </div>
        <button onClick={onClose} className="absolute -top-3 -right-3 w-7 h-7 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-muted">
          <X className="w-3.5 h-3.5 text-foreground" />
        </button>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────── */
/*  CHAPTER DETAIL DRAWER                                       */
/* ─────────────────────────────────────────────────────────── */

function ChapterDetailDrawer({ chapter, onClose }: { chapter: Chapter; onClose: () => void }) {
  const [note, setNote] = useState("");
  const [showSurvey, setShowSurvey] = useState(false);

  const recentEvents = [
    { name:"Rush Month Info Night",   date:"Jun 14",  attendees: chapter.attendance,                  nps: chapter.avgNpsScore },
    { name:"Tabling — Main Quad",     date:"Jun 7",   attendees: Math.round(chapter.attendance * 0.6), nps: chapter.avgNpsScore ? chapter.avgNpsScore - 6 : null },
    { name:"MEDLIFE Info Session",    date:"May 28",  attendees: Math.round(chapter.attendance * 0.8), nps: chapter.avgNpsScore ? chapter.avgNpsScore + 4 : null },
  ].slice(0, Math.min(chapter.eventsThisYear, 3));

  return (
    <>
      <div className="fixed inset-y-0 right-0 w-[580px] bg-white shadow-2xl z-50 flex flex-col border-l border-border">
        {/* Header */}
        <div className="flex items-start justify-between px-5 py-4 border-b border-border sticky top-0 bg-white z-10 flex-shrink-0">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider">Chapter Detail</span>
              <CampaignBadge status={chapter.campaignStatus} />
            </div>
            <h2 className="text-base font-bold text-foreground">{chapter.name}</h2>
            <div className="text-xs text-muted-foreground">{chapter.school}</div>
            <div className="flex items-center gap-3 mt-1.5 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><Globe className="w-3 h-3" />{chapter.country}</span>
              <span className="flex items-center gap-1"><Users className="w-3 h-3" />{chapter.activeMembers} members</span>
              <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{chapter.eventsThisYear} events this year</span>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-muted rounded-lg transition-colors">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">

          {/* Core 4 pillars */}
          <div className="grid grid-cols-4 gap-2">
            {[
              { label:"Events / Year", value: chapter.eventsThisYear,   accent:"bg-primary/10 text-primary" },
              { label:"Events / Month", value: chapter.eventsThisMonth, accent:"bg-primary/10 text-primary" },
              { label:"Total Leads",   value: chapter.leads,            accent:"bg-foreground/8 text-foreground" },
              { label:"Points / Year", value: (chapter.totalPointsYear/1000).toFixed(1)+"k", accent:"bg-amber-100 text-amber-700" },
            ].map(k => (
              <div key={k.label} className={`rounded-xl p-3 text-center ${k.accent}`}>
                <div className="text-xl font-mono font-bold leading-none">{k.value}</div>
                <div className="text-[10px] font-medium mt-1 opacity-70 leading-tight">{k.label}</div>
              </div>
            ))}
          </div>

          {/* Lead → Attendance funnel */}
          <div className="bg-white border border-border rounded-xl overflow-hidden">
            <div className="px-4 py-2.5 bg-muted/30 border-b border-border flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">Lead → Event Funnel</span>
              <span className={`text-sm font-mono font-bold ${chapter.leadAttendancePct >= 60 ? "text-emerald-600" : chapter.leadAttendancePct >= 40 ? "text-amber-600" : "text-red-500"}`}>
                {chapter.leadAttendancePct}% of leads attended
              </span>
            </div>
            <div className="px-4 py-3 flex items-end gap-3">
              {[
                { label:"Leads", n: chapter.leads, pct: 100, color:"bg-primary/70" },
                { label:"RSVPs", n: chapter.rsvps, pct: Math.round(chapter.rsvps/Math.max(chapter.leads,1)*100), color:"bg-primary/40" },
                { label:"Attended", n: chapter.attendance, pct: Math.round(chapter.attendance/Math.max(chapter.leads,1)*100), color:"bg-emerald-500" },
                { label:"New Mbrs", n: chapter.newMembers, pct: Math.round(chapter.newMembers/Math.max(chapter.leads,1)*100), color:"bg-amber-400" },
              ].map(s => (
                <div key={s.label} className="flex-1 flex flex-col items-center gap-1">
                  <span className="text-[10px] font-mono font-bold text-foreground">{s.n}</span>
                  <div className={`w-full rounded-t ${s.color}`} style={{ height: Math.max(s.pct * 0.5, 4) }} />
                  <span className="text-[9px] text-muted-foreground text-center leading-tight">{s.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Post-Event NPS */}
          <div className="bg-white border border-border rounded-xl overflow-hidden">
            <div className="px-4 py-2.5 bg-muted/30 border-b border-border flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">Post-Event NPS</span>
              <button onClick={() => setShowSurvey(true)} className="text-[10px] text-primary font-semibold hover:underline flex items-center gap-1">
                <Eye className="w-3 h-3" /> Preview Survey
              </button>
            </div>
            <div className="px-4 py-3">
              <div className="flex items-center gap-5 mb-3">
                <div className="text-center">
                  <div className="text-[10px] text-muted-foreground mb-1">Avg NPS</div>
                  <NpsScore score={chapter.avgNpsScore} />
                </div>
                <div className="text-center">
                  <div className="text-[10px] text-muted-foreground mb-1">Surveys Sent</div>
                  <div className="text-sm font-mono font-bold text-foreground">{chapter.eventsThisYear}</div>
                </div>
                <div className="text-center">
                  <div className="text-[10px] text-muted-foreground mb-1">Response Rate</div>
                  <div className="text-sm font-mono font-bold text-foreground">
                    {chapter.eventsThisYear > 0 ? `${Math.min(94, 58 + chapter.eventsThisYear)}%` : "—"}
                  </div>
                </div>
                <button className="ml-auto flex items-center gap-1.5 px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-semibold hover:bg-primary/90 transition-colors">
                  <Send className="w-3 h-3" /> Send NPS Survey
                </button>
              </div>
              {recentEvents.length > 0 ? (
                <div className="space-y-1.5">
                  {recentEvents.map((ev, i) => (
                    <div key={i} className="flex items-center gap-3 py-1.5 border-t border-border first:border-0">
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-medium text-foreground truncate">{ev.name}</div>
                        <div className="text-[10px] text-muted-foreground">{ev.date} · {ev.attendees} attendees</div>
                      </div>
                      <NpsScore score={ev.nps} />
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground italic text-center py-1">No events yet — NPS will appear after the first event.</p>
              )}
            </div>
          </div>

          {/* Campaigns (parallel) + Points */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-secondary rounded-xl p-3.5">
              <div className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider mb-2">Active Campaigns</div>
              {/* Primary campaign */}
              <div className="flex items-center justify-between mb-1.5">
                <div className="text-xs font-semibold text-foreground leading-tight">{chapter.campaign}</div>
                <CampaignBadge status={chapter.campaignStatus} />
              </div>
              {/* Second campaign — shown for established chapters running parallel campaigns */}
              {chapter.chapterType === "established" && (
                <div className="flex items-center justify-between pt-1.5 border-t border-border/60">
                  <div className="text-xs font-medium text-muted-foreground leading-tight">Chapter Engagement</div>
                  <CampaignBadge status="on-track" />
                </div>
              )}
              {/* Third for high-volume chapters */}
              {chapter.eventsThisYear >= 18 && (
                <div className="flex items-center justify-between pt-1.5 border-t border-border/60">
                  <div className="text-xs font-medium text-muted-foreground leading-tight">Grow the Movement</div>
                  <CampaignBadge status="on-track" />
                </div>
              )}
            </div>
            <div className="bg-amber-50 border border-amber-100 rounded-xl p-3.5">
              <div className="text-[10px] text-amber-700 font-semibold uppercase tracking-wider mb-1">Points / Year</div>
              <div className="text-2xl font-mono font-bold text-amber-600">{chapter.totalPointsYear.toLocaleString()}</div>
              <div className="text-[10px] text-amber-500 mt-0.5">+{chapter.pointsWeek.toLocaleString()} this week</div>
            </div>
          </div>

          {/* Coach + Leaders */}
          <div className="border border-border rounded-xl p-4 space-y-2.5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider">Coach</div>
                <div className="text-sm font-semibold text-foreground mt-0.5">{chapter.coach}</div>
              </div>
            </div>
            <div>
              <div className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wider mb-1.5">Leaders</div>
              <div className="flex flex-wrap gap-1.5">
                {chapter.leaders.map(l => (
                  <span key={l} className="bg-secondary text-primary px-2 py-0.5 rounded text-xs font-medium">{l}</span>
                ))}
              </div>
            </div>
          </div>

          {/* Coach Note */}
          <div>
            <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Coach Note</div>
            <textarea
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder={`Notes for ${chapter.name}…`}
              className="w-full bg-muted/50 rounded-lg p-3 text-sm text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:ring-2 focus:ring-primary/30 border border-border"
              rows={3}
            />
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-border p-4 flex gap-2 flex-shrink-0">
          <button className="flex-1 bg-primary text-white py-2 rounded-lg text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-1.5">
            <Send className="w-3.5 h-3.5" /> Send Content
          </button>
          <button onClick={() => setShowSurvey(true)} className="flex-1 bg-secondary border border-primary/20 text-primary py-2 rounded-lg text-sm font-semibold hover:bg-primary/10 transition-colors flex items-center justify-center gap-1.5">
            <Star className="w-3.5 h-3.5" /> Send NPS Survey
          </button>
          <button className="px-3 py-2 bg-muted text-foreground rounded-lg text-sm hover:bg-muted/70 transition-colors">
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {showSurvey && <NPSSurveyPreview onClose={() => setShowSurvey(false)} />}
    </>
  );
}

/* ─────────────────────────────────────────────────────────── */
/*  SCREEN 1 – PORTFOLIO OVERVIEW                              */
/* ─────────────────────────────────────────────────────────── */

function PortfolioOverview({ onSelectChapter }: { onSelectChapter: (c: Chapter) => void }) {
  const [search, setSearch] = useState("");
  const [regionFilter, setRegionFilter] = useState("all");
  const [coachFilter, setCoachFilter] = useState("all");
  const [sortBy, setSortBy] = useState<"name"|"nps"|"events"|"leads"|"leadPct"|"points">("name");
  const [showSurvey, setShowSurvey] = useState(false);

  const REGIONS = ["New England", "Mid Atlantic", "South", "Midwest", "West", "Puerto Rico", "UK", "Canada", "International"];
  const coaches = ["all", ...Array.from(new Set(CHAPTERS.map(c => c.coach))).sort()];

  const filtered = useMemo(() => {
    let list = CHAPTERS.filter(c => {
      if (search && !c.name.toLowerCase().includes(search.toLowerCase()) && !c.school.toLowerCase().includes(search.toLowerCase())) return false;
      if (regionFilter !== "all" && c.medlifeRegion !== regionFilter) return false;
      if (coachFilter !== "all" && c.coach !== coachFilter) return false;
      return true;
    });
    if (sortBy === "nps")     list = [...list].sort((a,b) => (b.avgNpsScore ?? -999) - (a.avgNpsScore ?? -999));
    if (sortBy === "events")  list = [...list].sort((a,b) => b.eventsThisYear - a.eventsThisYear);
    if (sortBy === "leads")   list = [...list].sort((a,b) => b.leads - a.leads);
    if (sortBy === "leadPct") list = [...list].sort((a,b) => b.leadAttendancePct - a.leadAttendancePct);
    if (sortBy === "points")  list = [...list].sort((a,b) => b.totalPointsYear - a.totalPointsYear);
    return list;
  }, [search, regionFilter, coachFilter, sortBy]);

  const avgEventsPerMonth = (CHAPTERS.reduce((a,c) => a + c.eventsThisMonth, 0) / CHAPTERS.length).toFixed(1);

  return (
    <div className="flex flex-col gap-5">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-3">
        <KPICard label="Chapters" value={CHAPTERS.length} sub="all active" color="blue" />
        <KPICard label="Avg Events / Month" value={avgEventsPerMonth} sub="per chapter average" color="blue" />
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-border p-3 flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-1 min-w-44 bg-muted/60 rounded-lg px-3 py-2">
          <Search className="w-3.5 h-3.5 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search chapter or school…"
            className="bg-transparent text-sm flex-1 outline-none placeholder:text-muted-foreground" />
          {search && <button onClick={() => setSearch("")}><X className="w-3 h-3 text-muted-foreground" /></button>}
        </div>
        <div className="relative">
          <select value={regionFilter} onChange={e => setRegionFilter(e.target.value)}
            className="bg-muted/60 text-sm px-3 py-2 rounded-lg pr-7 appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary/20 font-medium text-foreground">
            <option value="all">All Regions</option>
            {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
          <ChevronDown className="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
        </div>
        <div className="relative">
          <select value={coachFilter} onChange={e => setCoachFilter(e.target.value)}
            className="bg-muted/60 text-sm px-3 py-2 rounded-lg pr-7 appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary/20 font-medium text-foreground">
            <option value="all">All Coaches</option>
            {coaches.filter(o => o !== "all").map(o => <option key={o} value={o}>{o}</option>)}
          </select>
          <ChevronDown className="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
        </div>
        <div className="relative">
          <select value={sortBy} onChange={e => setSortBy(e.target.value as typeof sortBy)}
            className="bg-muted/60 text-sm px-3 py-2 rounded-lg pr-7 appearance-none cursor-pointer focus:outline-none font-medium text-foreground">
            <option value="name">Sort: Name</option>
            <option value="nps">Sort: NPS ↓</option>
            <option value="events">Sort: Events ↓</option>
            <option value="leads">Sort: Leads ↓</option>
            <option value="leadPct">Sort: Lead % ↓</option>
            <option value="points">Sort: Points ↓</option>
          </select>
          <ChevronDown className="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
        </div>
        <button className="ml-auto flex items-center gap-1.5 px-3 py-2 bg-muted text-foreground rounded-lg text-xs font-semibold hover:bg-muted/70 transition-colors">
          <Download className="w-3.5 h-3.5" /> Export
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-border overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <div className="text-sm font-semibold text-foreground">
            {filtered.length} chapters
            {filtered.length !== CHAPTERS.length && <span className="text-muted-foreground font-normal ml-1">filtered</span>}
          </div>
          <span className="text-[10px] text-muted-foreground">Click any row to open chapter detail</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-muted/40 border-b border-border">
                {[
                  "#", "Chapter", "Coach", "Region", "Events/Yr", "Events/Mo",
                  "Leads", "RSVPs", "Attended", "Lead→Event %", "Avg NPS", "Points/Yr"
                ].map(h => (
                  <th key={h} className="px-3 py-2.5 text-left text-muted-foreground font-semibold uppercase tracking-wider whitespace-nowrap text-[10px]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((ch, idx) => {
                const pctColor = ch.leadAttendancePct >= 65 ? "text-emerald-600" : ch.leadAttendancePct >= 45 ? "text-amber-600" : "text-red-500";
                return (
                  <tr key={ch.id} onClick={() => onSelectChapter(ch)}
                    className="border-b border-border last:border-0 cursor-pointer hover:bg-secondary/40 transition-colors group">
                    <td className="px-3 py-2.5 font-mono text-muted-foreground text-[11px] w-8">#{idx + 1}</td>
                    <td className="px-3 py-2.5">
                      <div className="font-semibold text-foreground leading-tight group-hover:text-primary transition-colors">{ch.name}</div>
                      <div className="text-muted-foreground text-[10px]">{ch.country}</div>
                    </td>
                    <td className="px-3 py-2.5 text-muted-foreground whitespace-nowrap">{ch.coach.split(" ")[0]}</td>
                    <td className="px-3 py-2.5 text-muted-foreground whitespace-nowrap text-[11px]">{ch.medlifeRegion}</td>
                    <td className="px-3 py-2.5 font-mono font-bold text-foreground text-center">{ch.eventsThisYear}</td>
                    <td className="px-3 py-2.5 text-center">
                      <span className={`font-mono font-semibold ${ch.eventsThisMonth === 0 ? "text-muted-foreground" : "text-foreground"}`}>
                        {ch.eventsThisMonth}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 font-mono font-semibold text-foreground">{ch.leads}</td>
                    <td className="px-3 py-2.5 font-mono text-foreground">{ch.rsvps}</td>
                    <td className="px-3 py-2.5 font-mono text-foreground">{ch.attendance}</td>
                    <td className="px-3 py-2.5 text-center">
                      <span className={`font-mono font-bold ${pctColor}`}>{ch.leadAttendancePct}%</span>
                    </td>
                    <td className="px-3 py-2.5 text-center">
                      <NpsScore score={ch.avgNpsScore} />
                    </td>
                    <td className="px-3 py-2.5 font-mono text-muted-foreground">{(ch.totalPointsYear/1000).toFixed(1)}k</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {showSurvey && <NPSSurveyPreview onClose={() => setShowSurvey(false)} />}
    </div>
  );
}

/* ─────────────────────────────────────────────────────────── */
/*  SCREEN 3 – CAMPAIGN OPERATIONS                             */
/* ─────────────────────────────────────────────────────────── */

// ── Campaign YoY historical data ──────────────────────────────────────────────
const CHAPTER_HISTORY: Record<string, {
  rush:   { lyMembers: number; lyEvents: number };
  slt:    { lyMembers: number; lySLT: number };
  mm:     { lyMembers: number; lyParticipants: number; lyFundraised: number };
  events: { lyMonthEvents: number; lyAnnualEvents: number };
  social: { ig: number; fb: number; tiktok: number; igLY: number; fbLY: number; tiktokLY: number };
}> = {
  ch1:  { rush:{lyMembers:42,lyEvents:15},  slt:{lyMembers:42,lySLT:7},  mm:{lyMembers:42,lyParticipants:32,lyFundraised:4100}, events:{lyMonthEvents:3,lyAnnualEvents:15}, social:{ig:3200,fb:1100,tiktok:1800,igLY:2600,fbLY:920,tiktokLY:800}  },
  ch2:  { rush:{lyMembers:19,lyEvents:4},   slt:{lyMembers:19,lySLT:2},  mm:{lyMembers:19,lyParticipants:13,lyFundraised:1200}, events:{lyMonthEvents:1,lyAnnualEvents:4},  social:{ig:980,fb:420,tiktok:310,igLY:800,fbLY:380,tiktokLY:90}     },
  ch3:  { rush:{lyMembers:55,lyEvents:18},  slt:{lyMembers:55,lySLT:10}, mm:{lyMembers:55,lyParticipants:41,lyFundraised:5800}, events:{lyMonthEvents:4,lyAnnualEvents:18}, social:{ig:2700,fb:1800,tiktok:2100,igLY:2100,fbLY:1500,tiktokLY:900} },
  ch4:  { rush:{lyMembers:30,lyEvents:12},  slt:{lyMembers:30,lySLT:5},  mm:{lyMembers:30,lyParticipants:22,lyFundraised:3100}, events:{lyMonthEvents:3,lyAnnualEvents:12}, social:{ig:1400,fb:700,tiktok:640,igLY:1100,fbLY:580,tiktokLY:200}   },
  ch5:  { rush:{lyMembers:36,lyEvents:7},   slt:{lyMembers:36,lySLT:5},  mm:{lyMembers:36,lyParticipants:27,lyFundraised:2200}, events:{lyMonthEvents:2,lyAnnualEvents:7},  social:{ig:1900,fb:1100,tiktok:750,igLY:1500,fbLY:950,tiktokLY:200}  },
  ch6:  { rush:{lyMembers:14,lyEvents:1},   slt:{lyMembers:14,lySLT:1},  mm:{lyMembers:14,lyParticipants:9,lyFundraised:600},  events:{lyMonthEvents:0,lyAnnualEvents:1},  social:{ig:480,fb:220,tiktok:90,igLY:350,fbLY:180,tiktokLY:0}        },
  ch7:  { rush:{lyMembers:49,lyEvents:16},  slt:{lyMembers:49,lySLT:9},  mm:{lyMembers:49,lyParticipants:37,lyFundraised:5100}, events:{lyMonthEvents:4,lyAnnualEvents:16}, social:{ig:2100,fb:1400,tiktok:1200,igLY:1700,fbLY:1100,tiktokLY:400} },
  ch8:  { rush:{lyMembers:24,lyEvents:5},   slt:{lyMembers:24,lySLT:3},  mm:{lyMembers:24,lyParticipants:17,lyFundraised:1400}, events:{lyMonthEvents:1,lyAnnualEvents:5},  social:{ig:790,fb:380,tiktok:220,igLY:640,fbLY:300,tiktokLY:60}      },
  ch9:  { rush:{lyMembers:34,lyEvents:11},  slt:{lyMembers:34,lySLT:6},  mm:{lyMembers:34,lyParticipants:26,lyFundraised:2900}, events:{lyMonthEvents:2,lyAnnualEvents:11}, social:{ig:1600,fb:920,tiktok:580,igLY:1300,fbLY:780,tiktokLY:150}   },
  ch10: { rush:{lyMembers:18,lyEvents:3},   slt:{lyMembers:18,lySLT:2},  mm:{lyMembers:18,lyParticipants:12,lyFundraised:900},  events:{lyMonthEvents:1,lyAnnualEvents:3},  social:{ig:560,fb:290,tiktok:130,igLY:440,fbLY:250,tiktokLY:40}      },
  ch11: { rush:{lyMembers:39,lyEvents:13},  slt:{lyMembers:39,lySLT:7},  mm:{lyMembers:39,lyParticipants:30,lyFundraised:3600}, events:{lyMonthEvents:3,lyAnnualEvents:13}, social:{ig:1800,fb:1100,tiktok:620,igLY:1400,fbLY:880,tiktokLY:180}  },
  ch12: { rush:{lyMembers:27,lyEvents:9},   slt:{lyMembers:27,lySLT:4},  mm:{lyMembers:27,lyParticipants:20,lyFundraised:2100}, events:{lyMonthEvents:2,lyAnnualEvents:9},  social:{ig:1100,fb:640,tiktok:320,igLY:870,fbLY:510,tiktokLY:80}     },
  ch13: { rush:{lyMembers:47,lyEvents:20},  slt:{lyMembers:47,lySLT:11}, mm:{lyMembers:47,lyParticipants:35,lyFundraised:6200}, events:{lyMonthEvents:4,lyAnnualEvents:20}, social:{ig:4200,fb:2100,tiktok:3100,igLY:3400,fbLY:1800,tiktokLY:1400}},
  ch14: { rush:{lyMembers:22,lyEvents:5},   slt:{lyMembers:22,lySLT:3},  mm:{lyMembers:22,lyParticipants:15,lyFundraised:1300}, events:{lyMonthEvents:1,lyAnnualEvents:5},  social:{ig:820,fb:390,tiktok:180,igLY:680,fbLY:330,tiktokLY:50}      },
  ch15: { rush:{lyMembers:43,lyEvents:14},  slt:{lyMembers:43,lySLT:8},  mm:{lyMembers:43,lyParticipants:33,lyFundraised:4400}, events:{lyMonthEvents:3,lyAnnualEvents:14}, social:{ig:2000,fb:1200,tiktok:880,igLY:1600,fbLY:980,tiktokLY:300}   },
  ch16: { rush:{lyMembers:16,lyEvents:3},   slt:{lyMembers:16,lySLT:2},  mm:{lyMembers:16,lyParticipants:11,lyFundraised:700},  events:{lyMonthEvents:0,lyAnnualEvents:3},  social:{ig:410,fb:190,tiktok:60,igLY:330,fbLY:160,tiktokLY:0}         },
  ch17: { rush:{lyMembers:57,lyEvents:18},  slt:{lyMembers:57,lySLT:12}, mm:{lyMembers:57,lyParticipants:43,lyFundraised:6800}, events:{lyMonthEvents:4,lyAnnualEvents:18}, social:{ig:3100,fb:2200,tiktok:1900,igLY:2500,fbLY:1800,tiktokLY:700} },
  ch18: { rush:{lyMembers:11,lyEvents:1},   slt:{lyMembers:11,lySLT:1},  mm:{lyMembers:11,lyParticipants:7,lyFundraised:400},   events:{lyMonthEvents:0,lyAnnualEvents:1},  social:{ig:280,fb:110,tiktok:40,igLY:180,fbLY:80,tiktokLY:0}          },
  ch19: { rush:{lyMembers:40,lyEvents:13},  slt:{lyMembers:40,lySLT:7},  mm:{lyMembers:40,lyParticipants:30,lyFundraised:3800}, events:{lyMonthEvents:2,lyAnnualEvents:13}, social:{ig:1700,fb:980,tiktok:720,igLY:1300,fbLY:810,tiktokLY:220}    },
  ch20: { rush:{lyMembers:51,lyEvents:17},  slt:{lyMembers:51,lySLT:10}, mm:{lyMembers:51,lyParticipants:39,lyFundraised:5600}, events:{lyMonthEvents:4,lyAnnualEvents:17}, social:{ig:3800,fb:1900,tiktok:2600,igLY:3100,fbLY:1600,tiktokLY:1100}},
};

// ── YoY helpers ───────────────────────────────────────────────────────────────
function yoyPct(ty: number, ly: number): number | null {
  if (ly === 0) return null;
  return Math.round(((ty - ly) / ly) * 100);
}

function YoYBadge({ ty, ly, prefix }: { ty: number; ly: number; prefix?: string }) {
  const pct = yoyPct(ty, ly);
  if (pct === null) return <span className="text-muted-foreground text-[10px]">—</span>;
  const up = pct > 0;
  const flat = pct === 0;
  return (
    <span className={`text-[11px] font-mono font-semibold ${up ? "text-emerald-600" : flat ? "text-muted-foreground" : "text-red-500"}`}>
      {up ? "↑" : flat ? "→" : "↓"}{Math.abs(pct)}%{prefix ? ` ${prefix}` : ""}
    </span>
  );
}

function PctBadge({ pct, lyPct }: { pct: number; lyPct: number }) {
  const color = pct >= 70 ? "text-emerald-600" : pct >= 50 ? "text-amber-600" : "text-red-500";
  return (
    <div>
      <span className={`text-xs font-mono font-bold ${color}`}>{pct}%</span>
      <span className="text-[10px] text-muted-foreground ml-1">vs {lyPct}% LY</span>
    </div>
  );
}

function CampaignOps() {
  const [activeCampaign, setActiveCampaign] = useState("Rush Month");
  const [regionFilter, setRegionFilter] = useState("all");
  const [coachFilter, setCoachFilter]   = useState("all");
  const [showRiskTooltip, setShowRiskTooltip] = useState(false);

  const CAMPAIGNS = [
    "Rush Month",
    "SLT Promotion",
    "Moving Mountains",
    "Chapter Events",
    "Leadership Transition",
    "Chapter Organization and Planning",
    "Social Media",
  ];

  const REGIONS = ["New England", "Mid Atlantic", "South", "Midwest", "West", "Puerto Rico", "UK", "Canada", "International"];

  // For Rush Month show all; others filter by campaign match
  // Social Media and Chapter Events show all chapters; others filter by campaign
  const campaignChapters = (activeCampaign === "Rush Month" || activeCampaign === "Social Media" || activeCampaign === "Chapter Events")
    ? CHAPTERS
    : CHAPTERS.filter(c => c.campaign === activeCampaign);

  // A chapter is at risk if: no events in last month OR attendance < 10
  const atRiskChapters = campaignChapters.filter(
    c => c.eventsThisMonth === 0 || c.attendance < 10
  );

  const coaches = ["all", ...Array.from(new Set(campaignChapters.map(c => c.coach))).sort()];

  const filtered = campaignChapters.filter(c => {
    if (regionFilter !== "all" && c.medlifeRegion !== regionFilter) return false;
    if (coachFilter  !== "all" && c.coach         !== coachFilter)  return false;
    return true;
  });

  const ACTION_SUGGESTIONS = [
    { icon:"📅", text:"Schedule a tabling or info event within the next 7 days" },
    { icon:"📱", text:"Contact chapter leaders directly via WhatsApp or email" },
    { icon:"✅", text:"Review the chapter's event planning checklist in myMEDLIFE" },
    { icon:"📞", text:"Book a 15-min coach check-in call to unblock the chapter" },
    { icon:"🌟", text:"Share a best-practice post from a high-performing chapter" },
    { icon:"🔍", text:"Check if an SOP step is blocking event creation or approval" },
  ];

  // Why a chapter is at risk
  const riskReason = (c: Chapter) => {
    const reasons: string[] = [];
    if (c.eventsThisMonth === 0) reasons.push("no events this month");
    if (c.attendance < 10)       reasons.push(`low attendance (${c.attendance})`);
    return reasons.join(" · ");
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Campaign Tabs */}
      <div className="flex gap-2 flex-wrap">
        {CAMPAIGNS.map(c => (
          <button key={c} onClick={() => { setActiveCampaign(c); setRegionFilter("all"); setCoachFilter("all"); }}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
              activeCampaign === c
                ? "bg-primary text-white shadow-sm"
                : "bg-white border border-border text-muted-foreground hover:border-primary/40 hover:text-foreground"
            }`}>
            {c}
          </button>
        ))}
      </div>

      {/* At-Risk Alert Bar with hover tooltip */}
      {atRiskChapters.length > 0 ? (
        <div className="relative"
          onMouseEnter={() => setShowRiskTooltip(true)}
          onMouseLeave={() => setShowRiskTooltip(false)}>
          <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex items-center gap-3 cursor-default select-none">
            <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <span className="text-sm font-semibold text-amber-800">
                {atRiskChapters.length} chapter{atRiskChapters.length !== 1 ? "s" : ""} at risk
              </span>
              <span className="text-xs text-amber-600 ml-2">
                — no events in the last month or attendance below 10
              </span>
              <div className="text-xs text-amber-600 mt-0.5 truncate">
                {atRiskChapters.slice(0, 4).map(c => c.name).join(", ")}
                {atRiskChapters.length > 4 ? ` +${atRiskChapters.length - 4} more` : ""}
              </div>
            </div>
            <span className="text-[10px] text-amber-500 font-medium flex-shrink-0 flex items-center gap-1">
              <Info className="w-3 h-3" /> Hover for suggestions
            </span>
          </div>

          {/* Hover tooltip — action suggestions */}
          {showRiskTooltip && (
            <div className="absolute top-full left-0 right-0 mt-1 z-30 bg-white border border-border rounded-xl shadow-xl p-4"
              onMouseEnter={() => setShowRiskTooltip(true)}
              onMouseLeave={() => setShowRiskTooltip(false)}>
              <div className="text-xs font-semibold text-foreground uppercase tracking-wider mb-3">
                Suggested Actions for At-Risk Chapters
              </div>
              <div className="grid grid-cols-2 gap-2 mb-4">
                {ACTION_SUGGESTIONS.map((s, i) => (
                  <div key={i} className="flex items-start gap-2 bg-muted/40 rounded-lg px-3 py-2">
                    <span className="text-sm flex-shrink-0">{s.icon}</span>
                    <span className="text-xs text-foreground leading-snug">{s.text}</span>
                  </div>
                ))}
              </div>
              <div className="border-t border-border pt-3">
                <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  At-risk chapters in {activeCampaign}
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  {atRiskChapters.map(c => (
                    <div key={c.id} className="flex items-center gap-2">
                      <AlertTriangle className="w-3 h-3 text-amber-400 flex-shrink-0" />
                      <div className="min-w-0">
                        <span className="text-xs font-medium text-foreground truncate block">{c.name}</span>
                        <span className="text-[10px] text-amber-600">{riskReason(c)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 flex items-center gap-3">
          <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0" />
          <span className="text-sm font-semibold text-emerald-800">All chapters on track</span>
          <span className="text-xs text-emerald-600 ml-1">— every chapter has events this month and attendance ≥ 10</span>
        </div>
      )}

      {/* Table with column filters */}
      <div className="bg-white rounded-xl border border-border overflow-hidden">
        {/* Filter bar */}
        <div className="px-4 py-3 border-b border-border flex items-center gap-3 flex-wrap">
          <div className="text-sm font-semibold text-foreground">
            {activeCampaign}
            <span className="text-muted-foreground font-normal ml-2 text-xs">{filtered.length} chapters</span>
          </div>
          {activeCampaign !== "Social Media" && (
            <div className="ml-auto flex items-center gap-2">
              <div className="relative">
                <select value={regionFilter} onChange={e => setRegionFilter(e.target.value)}
                  className="bg-muted/60 text-xs px-3 py-1.5 rounded-lg pr-7 appearance-none cursor-pointer focus:outline-none font-medium text-foreground">
                  <option value="all">All Regions</option>
                  {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
                <ChevronDown className="w-3 h-3 absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
              </div>
              <div className="relative">
                <select value={coachFilter} onChange={e => setCoachFilter(e.target.value)}
                  className="bg-muted/60 text-xs px-3 py-1.5 rounded-lg pr-7 appearance-none cursor-pointer focus:outline-none font-medium text-foreground">
                  <option value="all">All Coaches</option>
                  {coaches.filter(o => o !== "all").map(o => <option key={o} value={o}>{o}</option>)}
                </select>
                <ChevronDown className="w-3 h-3 absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
              </div>
            </div>
          )}
        </div>

        {/* ── Rush Month table ───────────────────────────────────────────── */}
        {activeCampaign === "Rush Month" && (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  {["Chapter","Coach","Region","Members TY","Members LY","Mbr YoY","Events TY","Events LY","Event YoY","% Mbrs Active","Status"].map(h => (
                    <th key={h} className="px-3 py-2.5 text-left text-muted-foreground font-semibold uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(ch => {
                  const h = CHAPTER_HISTORY[ch.id];
                  const isAtRisk = ch.eventsThisMonth === 0 || ch.attendance < 10;
                  const mbrPct = Math.round(ch.activeMembers / Math.max(ch.leads, 1) * 100);
                  const lyMbrPct = Math.round(h.rush.lyMembers / Math.max(h.rush.lyMembers + 5, 1) * 100);
                  return (
                    <tr key={ch.id} className={`border-b border-border last:border-0 hover:bg-muted/20 transition-colors ${isAtRisk ? "bg-amber-50/30" : ""}`}>
                      <td className="px-3 py-2.5"><div className="font-semibold text-foreground">{ch.name}</div><div className="text-[10px] text-muted-foreground">{ch.country}</div></td>
                      <td className="px-3 py-2.5 text-muted-foreground">{ch.coach.split(" ")[0]}</td>
                      <td className="px-3 py-2.5 text-muted-foreground">{ch.medlifeRegion}</td>
                      <td className="px-3 py-2.5 font-mono font-bold text-foreground">{ch.activeMembers}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{h.rush.lyMembers}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={ch.activeMembers} ly={h.rush.lyMembers} /></td>
                      <td className="px-3 py-2.5 font-mono font-bold text-foreground">{ch.eventsThisYear}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{h.rush.lyEvents}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={ch.eventsThisYear} ly={h.rush.lyEvents} /></td>
                      <td className="px-3 py-2.5"><PctBadge pct={mbrPct} lyPct={lyMbrPct} /></td>
                      <td className="px-3 py-2.5">
                        {isAtRisk
                          ? <span className="bg-amber-100 text-amber-700 border border-amber-200 px-2 py-0.5 rounded text-[10px] font-semibold">At Risk</span>
                          : <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded text-[10px] font-semibold">On Track</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* ── SLT Promotion table ────────────────────────────────────────── */}
        {activeCampaign === "SLT Promotion" && (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  {["Chapter","Coach","Region","Members TY","Members LY","Mbr YoY","SLT Students TY","SLT Students LY","SLT YoY","% on SLT (TY vs LY)","Status"].map(h => (
                    <th key={h} className="px-3 py-2.5 text-left text-muted-foreground font-semibold uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(ch => {
                  const h = CHAPTER_HISTORY[ch.id];
                  const tySLT = Math.round(ch.activeMembers * 0.16);
                  const tyPct = Math.round(tySLT / Math.max(ch.activeMembers, 1) * 100);
                  const lyPct = Math.round(h.slt.lySLT / Math.max(h.slt.lyMembers, 1) * 100);
                  const isAtRisk = ch.eventsThisMonth === 0 || ch.attendance < 10;
                  return (
                    <tr key={ch.id} className={`border-b border-border last:border-0 hover:bg-muted/20 transition-colors ${isAtRisk ? "bg-amber-50/30" : ""}`}>
                      <td className="px-3 py-2.5"><div className="font-semibold text-foreground">{ch.name}</div><div className="text-[10px] text-muted-foreground">{ch.country}</div></td>
                      <td className="px-3 py-2.5 text-muted-foreground">{ch.coach.split(" ")[0]}</td>
                      <td className="px-3 py-2.5 text-muted-foreground">{ch.medlifeRegion}</td>
                      <td className="px-3 py-2.5 font-mono font-bold text-foreground">{ch.activeMembers}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{h.slt.lyMembers}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={ch.activeMembers} ly={h.slt.lyMembers} /></td>
                      <td className="px-3 py-2.5 font-mono font-bold text-foreground">{tySLT}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{h.slt.lySLT}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={tySLT} ly={h.slt.lySLT} /></td>
                      <td className="px-3 py-2.5"><PctBadge pct={tyPct} lyPct={lyPct} /></td>
                      <td className="px-3 py-2.5">
                        {isAtRisk
                          ? <span className="bg-amber-100 text-amber-700 border border-amber-200 px-2 py-0.5 rounded text-[10px] font-semibold">At Risk</span>
                          : <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded text-[10px] font-semibold">On Track</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* ── Moving Mountains table ─────────────────────────────────────── */}
        {activeCampaign === "Moving Mountains" && (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  {["Chapter","Coach","Region","Members TY","Members LY","MM Participants TY","MM Participants LY","Part. YoY","% Participating (TY vs LY)","Fundraised TY","Fundraised LY","Fundraising YoY","Status"].map(h => (
                    <th key={h} className="px-3 py-2.5 text-left text-muted-foreground font-semibold uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(ch => {
                  const h = CHAPTER_HISTORY[ch.id];
                  const tyPart = Math.round(ch.activeMembers * 0.63);
                  const tyPct  = Math.round(tyPart / Math.max(ch.activeMembers, 1) * 100);
                  const lyPct  = Math.round(h.mm.lyParticipants / Math.max(h.mm.lyMembers, 1) * 100);
                  const tyFund = h.mm.lyFundraised + Math.round(h.mm.lyFundraised * 0.12);
                  const isAtRisk = ch.eventsThisMonth === 0 || ch.attendance < 10;
                  return (
                    <tr key={ch.id} className={`border-b border-border last:border-0 hover:bg-muted/20 transition-colors ${isAtRisk ? "bg-amber-50/30" : ""}`}>
                      <td className="px-3 py-2.5"><div className="font-semibold text-foreground">{ch.name}</div><div className="text-[10px] text-muted-foreground">{ch.country}</div></td>
                      <td className="px-3 py-2.5 text-muted-foreground">{ch.coach.split(" ")[0]}</td>
                      <td className="px-3 py-2.5 text-muted-foreground">{ch.medlifeRegion}</td>
                      <td className="px-3 py-2.5 font-mono font-bold text-foreground">{ch.activeMembers}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{h.mm.lyMembers}</td>
                      <td className="px-3 py-2.5 font-mono font-bold text-foreground">{tyPart}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{h.mm.lyParticipants}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={tyPart} ly={h.mm.lyParticipants} /></td>
                      <td className="px-3 py-2.5"><PctBadge pct={tyPct} lyPct={lyPct} /></td>
                      <td className="px-3 py-2.5 font-mono font-bold text-foreground">${tyFund.toLocaleString()}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">${h.mm.lyFundraised.toLocaleString()}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={tyFund} ly={h.mm.lyFundraised} /></td>
                      <td className="px-3 py-2.5">
                        {isAtRisk
                          ? <span className="bg-amber-100 text-amber-700 border border-amber-200 px-2 py-0.5 rounded text-[10px] font-semibold">At Risk</span>
                          : <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded text-[10px] font-semibold">On Track</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* ── Chapter Events table ───────────────────────────────────────── */}
        {activeCampaign === "Chapter Events" && (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  {["Chapter","Coach","Region","This Month Events","Same Month LY","Month YoY","Events This Year","Events LY (Annual)","Annual YoY","Status"].map(h => (
                    <th key={h} className="px-3 py-2.5 text-left text-muted-foreground font-semibold uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(ch => {
                  const h = CHAPTER_HISTORY[ch.id];
                  const isAtRisk = ch.eventsThisMonth === 0 || ch.attendance < 10;
                  return (
                    <tr key={ch.id} className={`border-b border-border last:border-0 hover:bg-muted/20 transition-colors ${isAtRisk ? "bg-amber-50/30" : ""}`}>
                      <td className="px-3 py-2.5"><div className="font-semibold text-foreground">{ch.name}</div><div className="text-[10px] text-muted-foreground">{ch.country}</div></td>
                      <td className="px-3 py-2.5 text-muted-foreground">{ch.coach.split(" ")[0]}</td>
                      <td className="px-3 py-2.5 text-muted-foreground">{ch.medlifeRegion}</td>
                      <td className="px-3 py-2.5 font-mono font-bold text-foreground">{ch.eventsThisMonth}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{h.events.lyMonthEvents}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={ch.eventsThisMonth} ly={h.events.lyMonthEvents} /></td>
                      <td className="px-3 py-2.5 font-mono font-bold text-foreground">{ch.eventsThisYear}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{h.events.lyAnnualEvents}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={ch.eventsThisYear} ly={h.events.lyAnnualEvents} /></td>
                      <td className="px-3 py-2.5">
                        {isAtRisk
                          ? <span className="bg-amber-100 text-amber-700 border border-amber-200 px-2 py-0.5 rounded text-[10px] font-semibold">At Risk</span>
                          : <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded text-[10px] font-semibold">On Track</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* ── Leadership Transition / Org & Planning — simple table ─────── */}
        {(activeCampaign === "Leadership Transition" || activeCampaign === "Chapter Organization and Planning") && (
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-muted/40 border-b border-border">
                {["Chapter","Coach","Region","Members","Status"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-muted-foreground font-semibold uppercase tracking-wider text-[10px]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(ch => {
                const isAtRisk = ch.eventsThisMonth === 0 || ch.attendance < 10;
                return (
                  <tr key={ch.id} className={`border-b border-border last:border-0 hover:bg-muted/20 transition-colors ${isAtRisk ? "bg-amber-50/30" : ""}`}>
                    <td className="px-4 py-3"><div className="font-semibold text-foreground">{ch.name}</div><div className="text-[10px] text-muted-foreground">{ch.school}</div></td>
                    <td className="px-4 py-3 text-muted-foreground">{ch.coach}</td>
                    <td className="px-4 py-3 text-muted-foreground">{ch.medlifeRegion}</td>
                    <td className="px-4 py-3 font-mono font-semibold text-foreground">{ch.activeMembers}</td>
                    <td className="px-4 py-3">
                      {isAtRisk
                        ? <span className="bg-amber-100 text-amber-700 border border-amber-200 px-2 py-0.5 rounded text-[10px] font-semibold">At Risk</span>
                        : <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded text-[10px] font-semibold">On Track</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}

        {/* ── Social Media table ────────────────────────────────────────── */}
        {activeCampaign === "Social Media" && (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  {["Chapter","Coach","Region","Instagram TY","Instagram LY","IG YoY","Facebook TY","Facebook LY","FB YoY","TikTok TY","TikTok LY","TikTok YoY","Total Followers","Total YoY"].map(h => (
                    <th key={h} className="px-3 py-2.5 text-left text-muted-foreground font-semibold uppercase tracking-wider text-[10px] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {CHAPTERS.map(ch => {
                  const s = CHAPTER_HISTORY[ch.id].social;
                  const tyTotal = s.ig + s.fb + s.tiktok;
                  const lyTotal = s.igLY + s.fbLY + s.tiktokLY;
                  return (
                    <tr key={ch.id} className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors">
                      <td className="px-3 py-2.5"><div className="font-semibold text-foreground">{ch.name}</div><div className="text-[10px] text-muted-foreground">{ch.country}</div></td>
                      <td className="px-3 py-2.5 text-muted-foreground">{ch.coach.split(" ")[0]}</td>
                      <td className="px-3 py-2.5 text-muted-foreground">{ch.medlifeRegion}</td>
                      <td className="px-3 py-2.5 font-mono font-bold" style={{color:"#E1306C"}}>{s.ig.toLocaleString()}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{s.igLY.toLocaleString()}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={s.ig} ly={s.igLY} /></td>
                      <td className="px-3 py-2.5 font-mono font-bold" style={{color:"#1877F2"}}>{s.fb.toLocaleString()}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{s.fbLY.toLocaleString()}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={s.fb} ly={s.fbLY} /></td>
                      <td className="px-3 py-2.5 font-mono font-bold text-foreground">{s.tiktok.toLocaleString()}</td>
                      <td className="px-3 py-2.5 font-mono text-muted-foreground">{s.tiktokLY.toLocaleString()}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={s.tiktok} ly={s.tiktokLY} /></td>
                      <td className="px-3 py-2.5 font-mono font-bold text-foreground">{tyTotal.toLocaleString()}</td>
                      <td className="px-3 py-2.5"><YoYBadge ty={tyTotal} ly={lyTotal} /></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────── */
/*  SCREEN 4 – PROOF / UGC REVIEW QUEUE                       */
/* ─────────────────────────────────────────────────────────── */

// ── Platform config ────────────────────────────────────────────
const PLATFORM_CONFIG: Record<Platform, { label: string; bg: string; text: string; dot: string }> = {
  linkedin:  { label:"LinkedIn",  bg:"#0A66C2", text:"#fff", dot:"bg-[#0A66C2]" },
  instagram: { label:"Instagram", bg:"#E1306C", text:"#fff", dot:"bg-[#E1306C]" },
  facebook:  { label:"Facebook",  bg:"#1877F2", text:"#fff", dot:"bg-[#1877F2]" },
  loom:      { label:"Loom",      bg:"#625DF5", text:"#fff", dot:"bg-[#625DF5]" },
  youtube:   { label:"YouTube",   bg:"#FF0000", text:"#fff", dot:"bg-[#FF0000]" },
  tiktok:    { label:"TikTok",    bg:"#010101", text:"#fff", dot:"bg-[#010101]" },
  upload:    { label:"Uploaded",  bg:"#64748B", text:"#fff", dot:"bg-slate-500" },
};

function PlatformBadge({ platform }: { platform: Platform }) {
  const p = PLATFORM_CONFIG[platform];
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold"
      style={{ backgroundColor: p.bg, color: p.text }}
    >
      {p.label}
    </span>
  );
}

function ProofUGCQueue() {
  const [statusFilter, setStatusFilter] = useState<"all" | ContentCard["visibility"]>("all");
  const [platformFilter, setPlatformFilter] = useState("all");
  const [selectedCard, setSelectedCard] = useState<ContentCard | null>(null);
  const [linkInput, setLinkInput] = useState("");
  const [linkSubmitting, setLinkSubmitting] = useState(false);
  const [linkSuccess, setLinkSuccess] = useState(false);

  const handleLinkSubmit = () => {
    if (!linkInput.trim()) return;
    setLinkSubmitting(true);
    setTimeout(() => { setLinkSubmitting(false); setLinkSuccess(true); setLinkInput(""); }, 1200);
    setTimeout(() => setLinkSuccess(false), 3000);
  };

  const filtered = UGC_CARDS.filter((c) => {
    if (statusFilter !== "all" && c.visibility !== statusFilter) return false;
    if (platformFilter !== "all" && c.platform !== platformFilter) return false;
    return true;
  });

  const pendingCount = UGC_CARDS.filter(c => c.visibility === "pending").length;

  return (
    <div className="flex gap-5 items-start">
      {/* Left: queue */}
      <div className="flex-1 min-w-0 flex flex-col gap-4">

        {/* Link paste bar */}
        <div className="bg-white rounded-xl border border-border p-4">
          <div className="flex items-center gap-2 mb-3">
            <Link className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold text-foreground">Submit a story link</span>
            <span className="text-xs text-muted-foreground">— paste from LinkedIn, Instagram, Facebook, Loom, YouTube, TikTok</span>
          </div>
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <input
                value={linkInput}
                onChange={(e) => setLinkInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleLinkSubmit()}
                placeholder="https://www.instagram.com/p/…  or  https://loom.com/share/…"
                className="w-full bg-muted/60 border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/25 pr-28"
              />
              {/* Platform quick-detect chips */}
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
                {(["linkedin","instagram","loom","facebook","youtube"] as Platform[]).map(p => (
                  <button
                    key={p}
                    onClick={() => setLinkInput(`https://${PLATFORM_CONFIG[p].label.toLowerCase()}.com/`)}
                    className="w-5 h-5 rounded-full text-white flex items-center justify-center text-[8px] font-black hover:scale-110 transition-transform"
                    style={{ backgroundColor: PLATFORM_CONFIG[p].bg }}
                    title={PLATFORM_CONFIG[p].label}
                  >
                    {PLATFORM_CONFIG[p].label[0]}
                  </button>
                ))}
              </div>
            </div>
            <button
              onClick={handleLinkSubmit}
              disabled={linkSubmitting || !linkInput.trim()}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 ${
                linkSuccess ? "bg-emerald-500 text-white" :
                "bg-primary text-white hover:bg-primary/90 disabled:opacity-40"
              }`}
            >
              {linkSubmitting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> :
               linkSuccess ? <CheckCircle className="w-3.5 h-3.5" /> :
               <Send className="w-3.5 h-3.5" />}
              {linkSuccess ? "Added!" : linkSubmitting ? "Fetching…" : "Submit"}
            </button>
          </div>
          {linkSuccess && (
            <div className="mt-2 text-xs text-emerald-600 font-medium flex items-center gap-1.5">
              <CheckCircle className="w-3.5 h-3.5" />
              Link preview fetched and added to the review queue.
            </div>
          )}
        </div>

        {/* Filter bar */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1 bg-white border border-border rounded-lg p-1">
            {([
              { key:"all", label:`All (${UGC_CARDS.length})` },
              { key:"pending", label:`Pending (${pendingCount})` },
              { key:"chapter", label:"Approved" },
              { key:"rejected", label:"Rejected" },
            ] as const).map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setStatusFilter(key)}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${statusFilter === key ? "bg-primary text-white" : "text-muted-foreground hover:text-foreground hover:bg-muted"}`}
              >
                {label}
              </button>
            ))}
          </div>
          <div className="relative">
            <select
              value={platformFilter}
              onChange={(e) => setPlatformFilter(e.target.value)}
              className="bg-white border border-border text-xs px-3 py-2 rounded-lg pr-7 appearance-none cursor-pointer focus:outline-none font-medium text-foreground"
            >
              <option value="all">All Platforms</option>
              {(Object.keys(PLATFORM_CONFIG) as Platform[]).map(p => (
                <option key={p} value={p}>{PLATFORM_CONFIG[p].label}</option>
              ))}
            </select>
            <ChevronDown className="w-3 h-3 absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          </div>
          <span className="text-xs text-muted-foreground ml-auto">{filtered.length} stories</span>
        </div>

        {/* Story cards grid */}
        <div className={`grid gap-4 ${selectedCard ? "grid-cols-2" : "grid-cols-3"}`}>
          {filtered.map((card) => {
            const isSelected = selectedCard?.id === card.id;
            const plat = card.platform ? PLATFORM_CONFIG[card.platform] : null;
            return (
              <div
                key={card.id}
                onClick={() => setSelectedCard(isSelected ? null : card)}
                className={`bg-white rounded-xl border overflow-hidden cursor-pointer transition-all hover:shadow-md group ${
                  isSelected ? "ring-2 ring-primary border-primary shadow-md" : "border-border hover:border-slate-300"
                } ${card.visibility === "rejected" ? "opacity-60" : ""}`}
              >
                {/* Preview image */}
                <div className="relative aspect-video overflow-hidden bg-slate-100">
                  <img
                    src={card.previewImage}
                    alt={card.linkTitle ?? card.assignment}
                    className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                  />
                  {/* Gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />

                  {/* Platform badge — top left */}
                  {plat && (
                    <div className="absolute top-2 left-2">
                      <PlatformBadge platform={card.platform!} />
                    </div>
                  )}

                  {/* Quality score — top right */}
                  <div className="absolute top-2 right-2">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold font-mono ${
                      card.qualityScore >= 85 ? "bg-emerald-500 text-white" :
                      card.qualityScore >= 65 ? "bg-amber-400 text-white" : "bg-red-500 text-white"
                    }`}>
                      Q{card.qualityScore}
                    </span>
                  </div>

                  {/* Duration pill — bottom right */}
                  {card.duration && (
                    <span className="absolute bottom-2 right-2 bg-black/70 text-white text-[10px] font-mono px-1.5 py-0.5 rounded flex items-center gap-1">
                      <Play className="w-2.5 h-2.5 fill-white" />{card.duration}
                    </span>
                  )}

                  {/* Domain — bottom left */}
                  {card.linkDomain && (
                    <span className="absolute bottom-2 left-2 text-white/80 text-[10px] font-mono">
                      {card.linkDomain}
                    </span>
                  )}
                </div>

                {/* Card body */}
                <div className="p-3">
                  {/* Title */}
                  <p className="text-xs font-semibold text-foreground leading-snug line-clamp-2 mb-1.5">
                    {card.linkTitle ?? card.assignment}
                  </p>

                  {/* Caption */}
                  {card.caption && (
                    <p className="text-[10px] text-muted-foreground leading-relaxed line-clamp-2 mb-2.5">
                      {card.caption}
                    </p>
                  )}

                  {/* Footer row */}
                  <div className="flex items-center justify-between gap-2 pt-2 border-t border-border">
                    <div className="min-w-0">
                      <div className="text-[10px] font-semibold text-foreground truncate">{card.chapter}</div>
                      <div className="text-[10px] text-muted-foreground">{card.student} · {card.submitted}</div>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <ConsentTag status={card.consent} />
                    </div>
                  </div>

                  {/* Engagement + status row */}
                  <div className="flex items-center gap-2 mt-2">
                    <span className={`text-[10px] font-semibold ${
                      card.engagementPotential === "high" ? "text-emerald-600" :
                      card.engagementPotential === "medium" ? "text-amber-600" : "text-muted-foreground"
                    }`}>
                      {card.engagementPotential === "high" ? "↑ High" : card.engagementPotential === "medium" ? "→ Medium" : "↓ Low"} potential
                    </span>
                    {card.views !== undefined && card.views > 0 && (
                      <span className="text-[10px] text-muted-foreground ml-auto flex items-center gap-1">
                        <Eye className="w-2.5 h-2.5" />{card.views}
                        <Heart className="w-2.5 h-2.5 ml-1" />{card.likes}
                      </span>
                    )}
                    <span className={`ml-auto text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                      card.visibility === "pending" ? "bg-amber-100 text-amber-700" :
                      card.visibility === "rejected" ? "bg-red-100 text-red-700" :
                      "bg-emerald-100 text-emerald-700"
                    }`}>
                      {card.visibility === "pending" ? "Pending" : card.visibility === "rejected" ? "Rejected" : "Approved"}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right: Review panel */}
      <div className="w-72 flex-shrink-0 sticky top-4 flex flex-col gap-3">
        {selectedCard ? (
          <div className="bg-white rounded-xl border border-border overflow-hidden">
            {/* Preview mini */}
            <div className="relative aspect-video overflow-hidden bg-slate-100">
              <img src={selectedCard.previewImage} alt="" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              {selectedCard.platform && (
                <div className="absolute top-2 left-2"><PlatformBadge platform={selectedCard.platform} /></div>
              )}
              {selectedCard.url && (
                <a href={selectedCard.url} target="_blank" rel="noreferrer"
                  className="absolute bottom-2 right-2 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded flex items-center gap-1 hover:bg-black/80 transition-colors"
                  onClick={e => e.stopPropagation()}>
                  <ExternalLink className="w-2.5 h-2.5" /> Open link
                </a>
              )}
            </div>

            <div className="px-4 py-3 border-b border-border">
              <div className="text-xs font-bold text-foreground leading-snug">{selectedCard.linkTitle ?? selectedCard.assignment}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5">{selectedCard.chapter} · {selectedCard.student}</div>
            </div>

            <div className="p-4 space-y-4">
              {/* Consent */}
              <div>
                <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5">Consent & Visibility</div>
                <ConsentTag status={selectedCard.consent} />
                <div className="text-[10px] text-muted-foreground mt-1.5 leading-relaxed">
                  {selectedCard.consent === "public" ? "May be used publicly and across all chapters." :
                   selectedCard.consent === "chapter-only" ? "Restricted to this chapter only — do not share wider." :
                   selectedCard.consent === "multi-chapter" ? "Can be shared with selected chapters." :
                   selectedCard.consent === "pending" ? "⚠ Awaiting student consent. Do not share yet." :
                   "🚫 No consent obtained. Cannot be shared."}
                </div>
              </div>

              {/* Approve for */}
              <div>
                <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Share to Feed</div>
                <div className="space-y-1.5">
                  {[
                    { label:"This chapter only", i:0 },
                    { label:"Selected chapters", i:1 },
                    { label:"All chapters", i:2 },
                    { label:"Global / Public", i:3 },
                  ].map(({ label, i }) => (
                    <button
                      key={label}
                      disabled={selectedCard.consent === "none" || (selectedCard.consent === "chapter-only" && i > 0) || selectedCard.consent === "pending"}
                      className="w-full text-left px-3 py-2 rounded-lg text-xs font-medium border border-border hover:bg-secondary hover:border-primary/30 transition-colors disabled:opacity-30 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      <Send className="w-3 h-3 text-primary flex-shrink-0" /> {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-1.5">
                <button className="w-full px-3 py-2 rounded-lg text-xs font-semibold bg-amber-500 text-white hover:bg-amber-600 transition-colors flex items-center justify-center gap-1.5">
                  <Star className="w-3.5 h-3.5" /> Mark as Best Practice
                </button>
                <div className="flex gap-1.5">
                  <button className="flex-1 px-3 py-2 rounded-lg text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 transition-colors">
                    Request Changes
                  </button>
                  <button className="flex-1 px-3 py-2 rounded-lg text-xs font-semibold bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 transition-colors">
                    Reject
                  </button>
                </div>
              </div>

              {/* Coach note */}
              <div>
                <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5">Coach Note</div>
                <textarea
                  placeholder="Add context or caption for this story…"
                  className="w-full bg-muted/50 rounded-lg p-2.5 text-xs text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:ring-1 focus:ring-primary/30 border border-border"
                  rows={3}
                />
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-border p-8 text-center">
            <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
              <Eye className="w-5 h-5 text-muted-foreground" />
            </div>
            <div className="text-sm font-semibold text-foreground mb-1">Select a story to review</div>
            <div className="text-xs text-muted-foreground leading-relaxed">Click any card to see consent status, sharing options, and actions.</div>
          </div>
        )}

        {/* Queue stats */}
        <div className="bg-white rounded-xl border border-border p-4">
          <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">Queue Summary</div>
          <div className="space-y-2">
            {[
              { label:"Pending review", value: UGC_CARDS.filter(c=>c.visibility==="pending").length, color:"text-amber-600" },
              { label:"Approved", value: UGC_CARDS.filter(c=>c.visibility!=="pending"&&c.visibility!=="rejected").length, color:"text-emerald-600" },
              { label:"Rejected", value: UGC_CARDS.filter(c=>c.visibility==="rejected").length, color:"text-red-500" },
              { label:"Consent pending", value: UGC_CARDS.filter(c=>c.consent==="pending").length, color:"text-amber-500" },
            ].map(s => (
              <div key={s.label} className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{s.label}</span>
                <span className={`text-sm font-bold font-mono ${s.color}`}>{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}


/* ─────────────────────────────────────────────────────────── */
/*  SCREEN 8 – BEST PRACTICES LIBRARY                          */
/* ─────────────────────────────────────────────────────────── */

function BestPracticesLibrary() {
  const [campaignFilter, setCampaignFilter] = useState("all");
  const [regionFilter, setRegionFilter] = useState("all");

  const BP_REGIONS = ["New England", "Mid Atlantic", "South", "Midwest", "West", "Puerto Rico", "UK", "Canada", "International"];
  const campaigns  = ["all", ...Array.from(new Set(BEST_PRACTICES.map((b) => b.campaign)))];

  const filtered = BEST_PRACTICES.filter((bp) => {
    if (campaignFilter !== "all" && bp.campaign !== campaignFilter) return false;
    // Best practices use country field; map to region bucket loosely for demo
    if (regionFilter !== "all") {
      const regionMap: Record<string, string> = { USA:"West", Canada:"Canada", Mexico:"International", Peru:"International", Brazil:"International" };
      const bpRegion = regionMap[bp.country] ?? "International";
      if (bpRegion !== regionFilter) return false;
    }
    return true;
  });

  return (
    <div className="flex flex-col gap-5">
      {/* Filters */}
      <div className="bg-white rounded-lg border border-border p-3 flex items-center gap-3">
        {[
          { label:"Campaign", value: campaignFilter, set: setCampaignFilter, opts: campaigns },
        ].map(({ label, value, set, opts }) => (
          <div key={label} className="relative">
            <select value={value} onChange={(e) => set(e.target.value)} className="bg-muted/60 text-sm px-3 py-2 rounded-lg pr-7 appearance-none cursor-pointer focus:outline-none font-medium text-foreground">
              <option value="all">All Campaigns</option>
              {opts.filter(o => o !== "all").map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
            <ChevronDown className="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          </div>
        ))}
        <div className="relative">
          <select value={regionFilter} onChange={e => setRegionFilter(e.target.value)} className="bg-muted/60 text-sm px-3 py-2 rounded-lg pr-7 appearance-none cursor-pointer focus:outline-none font-medium text-foreground">
            <option value="all">All Regions</option>
            {BP_REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
          <ChevronDown className="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
        </div>
        <div className="ml-auto">
          <span className="text-sm text-muted-foreground">{filtered.length} best practices</span>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 gap-4">
        {filtered.map((bp) => (
          <div key={bp.id} className="bg-white rounded-lg border border-border overflow-hidden hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between p-4 border-b border-border">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Award className="w-4 h-4 text-accent flex-shrink-0" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-accent">{bp.type}</span>
                </div>
                <h3 className="font-bold text-foreground leading-tight">{bp.title}</h3>
                <div className="text-xs text-muted-foreground mt-1">
                  {bp.chapter} · {bp.country} · {bp.campaign}
                </div>
              </div>
              <div className="flex-shrink-0 ml-3 text-right">
                <div className="text-xs text-muted-foreground">Eng. Score</div>
                <div className="text-2xl font-mono font-bold text-primary">{bp.engagementScore}</div>
              </div>
            </div>
            <div className="p-4 space-y-3">
              <div>
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Why it worked</div>
                <div className="text-xs text-foreground leading-relaxed">{bp.why}</div>
              </div>
              <div className="bg-emerald-50 border border-emerald-100 rounded px-3 py-2">
                <div className="text-[10px] font-semibold text-emerald-600 uppercase tracking-wider mb-0.5">KPI Result</div>
                <div className="text-xs font-bold text-emerald-800">{bp.kpiResult}</div>
              </div>
              <div>
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5">Recommended for</div>
                <div className="flex flex-wrap gap-1">
                  {bp.recommended.map((ch) => (
                    <span key={ch} className="bg-secondary text-primary px-2 py-0.5 rounded text-[10px] font-medium">{ch}</span>
                  ))}
                </div>
              </div>
            </div>
            <div className="px-4 pb-4 flex gap-2">
              <button className="flex-1 py-1.5 bg-primary text-white rounded text-xs font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-1">
                <Send className="w-3 h-3" /> Share to Feed
              </button>
              <button className="flex-1 py-1.5 bg-muted text-foreground rounded text-xs font-semibold hover:bg-muted/70 transition-colors flex items-center justify-center gap-1">
                <Mail className="w-3 h-3" /> Send to Coaches
              </button>
              <button className="py-1.5 px-2 bg-muted text-foreground rounded text-xs font-semibold hover:bg-muted/70 transition-colors">
                <Bookmark className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────── */
/*  SCREEN 9 – ADMIN SYSTEM HEALTH                            */
/* ─────────────────────────────────────────────────────────── */

function AdminHealth() {
  const integrations: { name: string; status: "live" | "mock" | "error" | "degraded"; lastSync: string; note?: string }[] = [
    { name:"HubSpot CRM", status:"live", lastSync:"2 min ago" },
    { name:"Luma Events", status:"live", lastSync:"8 min ago" },
    { name:"Data Hub / Warehouse", status:"live", lastSync:"15 min ago" },
    { name:"Power BI Reports", status:"degraded", lastSync:"4h ago", note:"Refresh token expiring soon" },
    { name:"n8n Automation", status:"live", lastSync:"1 min ago" },
    { name:"AI Summary Engine", status:"mock", lastSync:"n/a", note:"Using mock data in staging" },
  ];

  const outbox = [
    { id:1, event:"contact.created", source:"myMEDLIFE", dest:"HubSpot", status:"success", retries:0, error:"—", created:"Jun 17 14:21", processed:"Jun 17 14:21" },
    { id:2, event:"rsvp.confirmed", source:"Luma", dest:"myMEDLIFE", status:"success", retries:0, error:"—", created:"Jun 17 14:18", processed:"Jun 17 14:19" },
    { id:3, event:"evidence.approved", source:"myMEDLIFE", dest:"Data Hub", status:"failed", retries:3, error:"503 Service Unavailable", created:"Jun 17 13:44", processed:"—" },
    { id:4, event:"hubspot.task.created", source:"n8n", dest:"HubSpot", status:"pending", retries:0, error:"—", created:"Jun 17 13:30", processed:"—" },
    { id:5, event:"member.joined", source:"myMEDLIFE", dest:"HubSpot", status:"success", retries:0, error:"—", created:"Jun 17 12:55", processed:"Jun 17 12:55" },
    { id:6, event:"ai.summary.drafted", source:"AI Engine", dest:"myMEDLIFE", status:"success", retries:0, error:"—", created:"Jun 17 12:00", processed:"Jun 17 12:01" },
    { id:7, event:"chapter.data.sync", source:"n8n", dest:"Power BI", status:"failed", retries:2, error:"Token expired", created:"Jun 17 10:00", processed:"—" },
  ];

  const auditLog = [
    { actor:"maria.santos@medlife.org", action:"Approved evidence", object:"PUCP Lima — Tabling Video", ts:"Jun 17 14:30", role:"Coach", chapter:"PUCP Lima" },
    { actor:"james.okafor@medlife.org", action:"Set decision: Intervene", object:"Yale University", ts:"Jun 17 13:55", role:"Coach", chapter:"Yale University" },
    { actor:"admin@medlife.org", action:"Shared post to 28 chapters", object:"Stanford QR Best Practice", ts:"Jun 17 13:20", role:"Admin", chapter:"Global" },
    { actor:"aisha.kamara@medlife.org", action:"Wrote coach note", object:"McGill University", ts:"Jun 17 12:44", role:"Coach", chapter:"McGill University" },
    { actor:"system@n8n", action:"Triggered automation", object:"Rush Month — follow-up sequence", ts:"Jun 17 12:00", role:"System", chapter:"All" },
  ];

  return (
    <div className="flex flex-col gap-5">
      {/* Integration Status */}
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-1 bg-white rounded-lg border border-border overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
            <Activity className="w-3.5 h-3.5 text-primary" />
            <span className="text-sm font-semibold text-foreground">Integration Status</span>
          </div>
          <div className="px-4 py-2">
            {integrations.map((i) => (
              <div key={i.name}>
                <IntegrationStatus name={i.name} status={i.status} lastSync={i.lastSync} />
                {i.note && <div className="text-[10px] text-amber-600 pb-2 -mt-1">{i.note}</div>}
              </div>
            ))}
          </div>
        </div>

        <div className="col-span-2 bg-white rounded-lg border border-border overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <Zap className="w-3.5 h-3.5 text-primary" />
              <span className="text-sm font-semibold text-foreground">Automation Outbox</span>
            </div>
            <div className="flex gap-2">
              <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded text-xs font-semibold">{outbox.filter(o=>o.status==="failed").length} failed</span>
              <button className="flex items-center gap-1 text-xs text-primary hover:underline"><RotateCcw className="w-3 h-3" /> Retry Failed</button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-muted/40 border-b border-border">
                  {["Event","Source","Destination","Status","Retries","Error","Created","Processed"].map((h) => (
                    <th key={h} className="px-3 py-2 text-left text-muted-foreground font-semibold uppercase tracking-wider text-[10px]">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {outbox.map((row) => (
                  <tr key={row.id} className={`border-b border-border last:border-0 ${row.status === "failed" ? "bg-red-50/30" : ""}`}>
                    <td className="px-3 py-2 font-mono text-foreground font-medium">{row.event}</td>
                    <td className="px-3 py-2 text-muted-foreground">{row.source}</td>
                    <td className="px-3 py-2 text-muted-foreground">{row.dest}</td>
                    <td className="px-3 py-2">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${row.status === "success" ? "bg-emerald-100 text-emerald-700" : row.status === "failed" ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"}`}>
                        {row.status}
                      </span>
                    </td>
                    <td className="px-3 py-2 font-mono text-center">{row.retries}</td>
                    <td className="px-3 py-2 text-muted-foreground text-[10px] max-w-32 truncate">{row.error}</td>
                    <td className="px-3 py-2 font-mono text-[10px] text-muted-foreground whitespace-nowrap">{row.created}</td>
                    <td className="px-3 py-2 font-mono text-[10px] text-muted-foreground whitespace-nowrap">{row.processed}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Audit Log */}
      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
          <Shield className="w-3.5 h-3.5 text-primary" />
          <span className="text-sm font-semibold text-foreground">Audit Log</span>
        </div>
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-muted/40 border-b border-border">
              {["Actor","Role","Action","Object","Chapter","Timestamp"].map((h) => (
                <th key={h} className="px-3 py-2.5 text-left text-muted-foreground font-semibold uppercase tracking-wider text-[10px]">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {auditLog.map((row, i) => (
              <tr key={i} className="border-b border-border last:border-0 hover:bg-muted/10 transition-colors">
                <td className="px-3 py-2.5 font-mono text-foreground text-[11px]">{row.actor}</td>
                <td className="px-3 py-2.5">
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${row.role === "Admin" ? "bg-violet-100 text-violet-700" : row.role === "System" ? "bg-gray-100 text-gray-600" : "bg-sky-100 text-sky-700"}`}>
                    {row.role}
                  </span>
                </td>
                <td className="px-3 py-2.5 text-foreground">{row.action}</td>
                <td className="px-3 py-2.5 text-muted-foreground max-w-48 truncate">{row.object}</td>
                <td className="px-3 py-2.5 text-muted-foreground">{row.chapter}</td>
                <td className="px-3 py-2.5 font-mono text-[10px] text-muted-foreground">{row.ts}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────── */
/*  ADMIN ROLE GATE                                             */
/* ─────────────────────────────────────────────────────────── */

type AdminRole = "ds-admin" | "super-admin";

function AdminRoleGate({ onGrant }: { onGrant: (role: AdminRole) => void }) {
  const [picked, setPicked] = useState<AdminRole>("ds-admin");

  return (
    <div className="flex-1 flex items-center justify-center bg-[#0d1117]">
      <div className="w-full max-w-sm text-center space-y-6">
        {/* Lock icon */}
        <div className="flex items-center justify-center">
          <div className="w-14 h-14 rounded-full bg-sky-500/10 border border-sky-500/20 flex items-center justify-center">
            <Shield className="w-6 h-6 text-sky-400" />
          </div>
        </div>

        <div>
          <h2 className="text-lg font-bold text-white mb-1">Restricted Access</h2>
          <p className="text-sm text-slate-400 leading-relaxed">
            The Admin panel is restricted to <span className="text-sky-400 font-semibold">DS Admin</span> and{" "}
            <span className="text-sky-400 font-semibold">Super Admin</span> roles only.
            All actions are logged and audited.
          </p>
        </div>

        {/* Role selector */}
        <div className="bg-[#161b22] border border-white/[0.08] rounded-xl p-5 text-left space-y-3">
          <p className="text-[11px] text-slate-600 font-mono uppercase tracking-wider mb-1">Sign in as</p>
          {([
            { value: "ds-admin" as AdminRole, label: "DS Admin", desc: "Data Systems Administrator — full read access, no key rotation" },
            { value: "super-admin" as AdminRole, label: "Super Admin", desc: "Full access including API key rotation, write toggles, and role changes" },
          ]).map(({ value, label, desc }) => (
            <label
              key={value}
              className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                picked === value ? "border-sky-500/40 bg-sky-500/8" : "border-white/[0.05] hover:border-white/[0.1]"
              }`}
            >
              <input
                type="radio"
                name="role"
                value={value}
                checked={picked === value}
                onChange={() => setPicked(value)}
                className="mt-0.5 accent-sky-500 flex-shrink-0"
              />
              <div>
                <div className={`text-sm font-semibold ${picked === value ? "text-sky-300" : "text-slate-300"}`}>{label}</div>
                <div className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">{desc}</div>
              </div>
            </label>
          ))}
        </div>

        <button
          onClick={() => onGrant(picked)}
          className="w-full py-2.5 bg-sky-500 text-white rounded-lg text-sm font-semibold hover:bg-sky-400 transition-colors"
        >
          Enter Admin Panel
        </button>

        <p className="text-[11px] text-slate-700">
          Not DS Admin or Super Admin?{" "}
          <button className="text-slate-500 underline underline-offset-2">Return to dashboard</button>
        </p>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────── */
/*  TOP NAV                                                     */
/* ─────────────────────────────────────────────────────────── */

const NAV_ITEMS: { key: Screen; label: string; icon: JSX.Element }[] = [
  { key:"chapters", label:"Chapters", icon:<LayoutDashboard className="w-3.5 h-3.5" /> },
  { key:"campaigns", label:"Campaigns", icon:<Megaphone className="w-3.5 h-3.5" /> },
  { key:"ugc", label:"Proof / UGC", icon:<Film className="w-3.5 h-3.5" /> },
  { key:"best-practices", label:"Best Practices", icon:<BookOpen className="w-3.5 h-3.5" /> },
  { key:"sops", label:"Campaign SOPs", icon:<GitBranch className="w-3.5 h-3.5" /> },
  { key:"admin", label:"Admin", icon:<Settings className="w-3.5 h-3.5" /> },
];

const SCREEN_TITLES: Record<Screen, string> = {
  chapters: "Portfolio Overview",
  campaigns: "Campaign Operations",
  events: "Events",
  ugc: "Proof / UGC Review Queue",
  reports: "Reports",
  admin: "System Health",
  "best-practices": "Best Practices Library",
  sops: "Campaign SOP Builder",
};

/* ─────────────────────────────────────────────────────────── */
/*  APP ROOT                                                    */
/* ─────────────────────────────────────────────────────────── */

export default function App() {
  const [activeScreen, setActiveScreen] = useState<Screen>("chapters");
  const [selectedChapter, setSelectedChapter] = useState<Chapter | null>(null);

  // SOP Builder sub-navigation
  const [sopView, setSopView] = useState<"library" | "builder">("library");
  const [sopCampaign, setSopCampaign] = useState<SOPCampaign | null>(null);

  // Admin panel — DS Admin / Super Admin gate
  const [adminRole, setAdminRole] = useState<AdminRole | null>(null);

  const handleSelectChapter = (ch: Chapter) => {
    setSelectedChapter(ch);
  };

  const handleNavChange = (key: Screen) => {
    setActiveScreen(key);
    if (key !== "chapters") setSelectedChapter(null);
    if (key !== "sops") { setSopView("library"); setSopCampaign(null); }
    if (key !== "admin") setAdminRole(null);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col" style={{ fontFamily:"'Plus Jakarta Sans', system-ui, sans-serif" }}>
      {/* Top Bar */}
      <header className="bg-sidebar border-b border-sidebar-border flex-shrink-0 z-30 relative">
        <div className="flex items-center h-12 px-5 gap-6">
          {/* Logo */}
          <button
            onClick={() => handleNavChange("chapters")}
            className="flex items-center gap-2.5 flex-shrink-0 hover:opacity-80 transition-opacity"
          >
            <div className="w-7 h-7 rounded bg-accent flex items-center justify-center text-xs font-black text-sidebar">M</div>
            <div className="text-left">
              <div className="text-white text-sm font-bold leading-tight">myMEDLIFE</div>
              <div className="text-sidebar-foreground/50 text-[9px] font-medium uppercase tracking-widest leading-tight">Staff Command Center</div>
            </div>
          </button>

          {/* Nav */}
          <nav className="flex items-center gap-0.5 flex-1">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.key}
                onClick={() => handleNavChange(item.key)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeScreen === item.key
                    ? "bg-sidebar-accent text-white"
                    : "text-sidebar-foreground/70 hover:text-white hover:bg-sidebar-accent/50"
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right */}
          <div className="flex items-center gap-3 flex-shrink-0">
            <div className="flex items-center gap-1.5 bg-red-600/20 border border-red-500/30 px-2.5 py-1 rounded-lg">
              <AlertTriangle className="w-3 h-3 text-red-400" />
              <span className="text-red-300 text-xs font-semibold">2 chapters need intervention</span>
            </div>
            <div className="w-7 h-7 rounded-full bg-accent flex items-center justify-center text-xs font-bold text-sidebar">JS</div>
          </div>
        </div>
      </header>

      {/* Page Header */}
      <div className="bg-white border-b border-border px-6 py-3 flex items-center justify-between flex-shrink-0">
        <div>
          <h1 className="text-base font-bold text-foreground">{SCREEN_TITLES[activeScreen]}</h1>
          <div className="text-xs text-muted-foreground mt-0.5">
            {activeScreen === "chapters" && `${CHAPTERS.length} chapters · Rush Month active · Last updated 2 min ago`}
            {activeScreen === "campaigns" && "7 campaigns active across all regions"}
            {activeScreen === "ugc" && `${UGC_CARDS.filter(c=>c.visibility==="pending").length} items pending review`}
            {activeScreen === "best-practices" && `${BEST_PRACTICES.length} verified best practices ready to share`}
            {activeScreen === "admin" && (adminRole ? `Signed in as ${adminRole === "super-admin" ? "Super Admin" : "DS Admin"} · Full system access` : "Restricted to DS Admin and Super Admin only")}
            {activeScreen === "sops" && (sopView === "builder" && sopCampaign ? `${sopCampaign.name} · ${sopCampaign.version}` : "Build, version, and publish campaign workflows — steps, roles, points, and comms")}
          </div>
        </div>
        <div className="text-xs text-muted-foreground font-mono">Jun 17, 2026 · 14:41 UTC</div>
      </div>

      {/* Content */}
      <main className={`flex-1 flex flex-col ${activeScreen === "sops" ? "overflow-hidden" : "overflow-auto"}`}>
        {/* SOP Builder — owns its own full-height layout */}
        {activeScreen === "sops" && (
          sopView === "library" ? (
            <SOPLibraryScreen
              onOpen={(c) => { setSopCampaign(c); setSopView("builder"); }}
            />
          ) : sopCampaign ? (
            <SOPBuilderScreen
              campaign={sopCampaign}
              onBack={() => { setSopView("library"); setSopCampaign(null); }}
            />
          ) : null
        )}

        {/* Admin — role gate (shown before access granted) */}
        {activeScreen === "admin" && !adminRole && (
          <AdminRoleGate onGrant={(role) => setAdminRole(role)} />
        )}

        {/* All other non-admin, non-SOP screens */}
        {activeScreen !== "sops" && activeScreen !== "admin" && (
          <div className="px-6 py-5 max-w-[1600px] mx-auto w-full">
            {activeScreen === "chapters" && <PortfolioOverview onSelectChapter={handleSelectChapter} />}
            {activeScreen === "campaigns" && <CampaignOps />}
            {activeScreen === "ugc" && <ProofUGCQueue />}
            {activeScreen === "best-practices" && <BestPracticesLibrary />}
          </div>
        )}
      </main>

      {/* Admin Panel full-screen overlay — DS Admin / Super Admin only */}
      {activeScreen === "admin" && adminRole && (
        <div className="fixed inset-0 z-[60] flex flex-col">
          <AdminPanel onBack={() => { setAdminRole(null); handleNavChange("chapters"); }} />
        </div>
      )}

      {/* Chapter Detail Drawer */}
      {selectedChapter && (
        <>
          <div
            className="fixed inset-0 bg-black/30 z-40 backdrop-blur-[1px]"
            onClick={() => setSelectedChapter(null)}
          />
          <div className="relative z-50">
            <ChapterDetailDrawer chapter={selectedChapter} onClose={() => setSelectedChapter(null)} />
          </div>
        </>
      )}
    </div>
  );
}
